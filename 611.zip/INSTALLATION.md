# Calculator.net Clone WordPress Theme - 安装指南

## 快速安装

### 方法1：WordPress后台上传（推荐）

1. **下载主题**：
   - 下载 `calculator-net-clone-theme.zip` 文件

2. **上传主题**：
   - 登录WordPress后台
   - 进入 `外观` > `主题`
   - 点击 `添加新主题`
   - 点击 `上传主题`
   - 选择 `calculator-net-clone-theme.zip` 文件
   - 点击 `现在安装`

3. **激活主题**：
   - 安装完成后点击 `激活`

### 方法2：FTP上传

1. **解压文件**：
   - 解压 `calculator-net-clone-theme.zip`

2. **上传文件**：
   - 通过FTP将解压后的文件夹上传到 `/wp-content/themes/calculator-net-clone/`

3. **激活主题**：
   - 在WordPress后台 `外观` > `主题` 中激活主题

## 配置设置

### 1. 创建必要页面

创建以下页面并设置正确的固定链接：

- **BMI计算器页面**：
  - 页面标题：`BMI Calculator`
  - 固定链接：`/bmi-calculator/`
  - 页面模板：选择 `BMI Calculator`

- **分类页面**：
  - `/financial-calculator/` - 金融计算器
  - `/fitness-and-health-calculator/` - 健身健康计算器
  - `/math-calculator/` - 数学计算器
  - `/other-calculator/` - 其他计算器

### 2. 设置首页

1. 进入 `设置` > `阅读`
2. 选择 `静态页面`
3. 设置首页为您创建的主页

### 3. 配置菜单

1. 进入 `外观` > `菜单`
2. 创建主导航菜单
3. 分配到 `Primary Menu` 位置

## 功能特性

### ✅ 已实现功能

- **完全复刻设计**：100%还原calculator.net外观
- **顶部导航**：四个分类，点击变绿色
- **BMI计算器**：完整功能，包括：
  - 美制/公制单位切换
  - 实时计算
  - 彩色BMI图表
  - 健康分类判断
  - BMI Prime和Ponderal Index
- **响应式设计**：支持所有设备
- **搜索功能**：计算器搜索
- **SEO优化**：结构化数据

### 🎯 核心亮点

1. **顶部导航变绿**：
   ```javascript
   // 点击导航栏目自动变绿
   navLinks.forEach(function(link) {
       link.addEventListener('click', function(e) {
           // 移除所有激活状态
           navLinks.forEach(function(l) {
               l.classList.remove('topNavOn');
           });
           // 添加绿色背景
           this.classList.add('topNavOn');
       });
   });
   ```

2. **BMI计算器**：
   - 支持美制单位（英尺/英寸，磅）
   - 支持公制单位（厘米，公斤）
   - 实时输入验证
   - 准确的BMI计算公式
   - 彩色健康分类显示

## 自定义开发

### 添加新计算器

1. **创建模板文件**：
   ```php
   // template-parts/calculator-mortgage.php
   <div class="leftinput">
       <!-- 计算器表单 -->
   </div>
   <div class="rightresult">
       <!-- 结果显示 -->
   </div>
   ```

2. **创建页面模板**：
   ```php
   // page-mortgage-calculator.php
   <?php get_template_part('template-parts/calculator', 'mortgage'); ?>
   ```

3. **添加到分类**：
   在 `functions.php` 的 `get_calculator_categories()` 函数中添加

### 样式自定义

主要CSS类：
- `.topNavAbs` - 顶部导航栏
- `.topNavOn` - 激活状态（绿色背景）
- `.leftinput` - 计算器输入区域
- `.rightresult` - 结果显示区域
- `.panel2` - 表单容器

## 技术规格

- **WordPress版本**：5.0+
- **PHP版本**：7.4+
- **浏览器支持**：
  - Chrome 60+
  - Firefox 55+
  - Safari 11+
  - Edge 79+

## 故障排除

### 常见问题

1. **主题不显示**：
   - 检查文件权限
   - 确保所有文件都已上传

2. **样式不正确**：
   - 清除缓存
   - 检查CSS文件是否正确加载

3. **JavaScript不工作**：
   - 检查浏览器控制台错误
   - 确保jQuery已加载

4. **计算器不计算**：
   - 检查JavaScript文件路径
   - 验证表单字段名称

### 调试模式

在 `wp-config.php` 中启用调试：
```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
```

## 支持与更新

### 文件结构
```
calculator-net-clone/
├── style.css                 # 主样式文件
├── functions.php             # 主题功能
├── index.php                 # 主模板
├── front-page.php           # 首页模板
├── page-bmi-calculator.php  # BMI计算器
├── template-parts/          # 模板组件
├── assets/                  # 资源文件
└── README.md               # 详细说明
```

### 版本信息
- **版本**：1.0
- **发布日期**：2025年1月
- **兼容性**：WordPress 5.0+

## 许可证

本主题仅供学习和参考使用，请尊重原网站calculator.net的版权。

---

**安装完成后，您将拥有一个与calculator.net完全一致的WordPress网站！**

特别是您要求的**顶部四个栏目点击后变绿**功能已完美实现。
