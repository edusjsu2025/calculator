<span id="ucframe"></span>
<div class="leftinput">
    <div id="topmenu" class="topmenucenter">
        <ul>
            <li><a href="#" onclick="return popMenu('standard',1);">US Units</a></li> 
            <li id="menuon"><a href="#" onclick="return popMenu('metric',1);">Metric Units</a></li> 
            <li><a href="#" onclick="return popMenu('other',0);">Other Units</a></li>
        </ul>
    </div>
    
    <div class="panel2">
        <table border="0" cellpadding="0" cellspacing="0" align="center">
            <tbody>
                <tr>
                    <td>
                        <form name="calform" id="bmi-calculator-form">
                            <table id="calinputtable" width="300">
                                <tbody>
                                    <tr>
                                        <td width="60">Age</td>
                                        <td width="240">
                                            <input type="text" name="cage" id="cage" value="25" class="inhalf" onkeyup="iptfieldCheck(this, 'r', 'pn');"> 
                                            &nbsp;ages: 2 - 120
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Gender</td>
                                        <td>
                                            <label for="csex1" class="cbcontainer">
                                                <input type="radio" name="csex" id="csex1" value="m" checked="">
                                                <span class="rbmark"></span>Male
                                            </label> 
                                            &nbsp; 
                                            <label for="csex2" class="cbcontainer">
                                                <input type="radio" name="csex" id="csex2" value="f">
                                                <span class="rbmark"></span>Female
                                            </label>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            
                            <table width="300" id="standardheightweight" bgcolor="#eeeeee" style="display: none;">
                                <tbody>
                                    <tr>
                                        <td width="60">Height</td>
                                        <td width="240">
                                            <table border="0" cellpadding="0" cellspacing="0">
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <input type="text" name="cheightfeet" id="cheightfeet" value="5" class="inhalf inuifoot" onkeyup="iptfieldCheck(this, '', 'pzn');">
                                                            <span class="inuifootspan">feet</span>
                                                        </td>
                                                        <td>&nbsp;&nbsp;</td>
                                                        <td>
                                                            <input type="text" name="cheightinch" id="cheightinch" value="10" class="inhalf inuiinch" onkeyup="iptfieldCheck(this, '', 'pzn');">
                                                            <span class="inuiinchspan">inches</span>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Weight</td>
                                        <td>
                                            <input type="text" name="cpound" id="cpound" value="160" class="infull inuipound" onkeyup="iptfieldCheck(this, 'r', 'pn');">
                                            <span class="inuipoundspan">pounds</span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            
                            <table width="300" id="metricheightweight" bgcolor="#eeeeee" style="display: block;">
                                <tbody>
                                    <tr>
                                        <td width="60">Height</td>
                                        <td width="240">
                                            <input type="text" name="cheightmeter" id="cheightmeter" value="180" class="infull inuick" onkeyup="iptfieldCheck(this, 'r', 'pn');">
                                            <span class="inuickspan">cm</span>
                                        </td>
                                    </tr>
                                    <tr id="metricweight">
                                        <td>Weight</td>
                                        <td>
                                            <input type="text" name="ckg" id="ckg" value="65" class="infull inuick" onkeyup="iptfieldCheck(this, 'r', 'pn');">
                                            <span class="inuickspan">kg</span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            
                            <table width="264">
                                <tbody>
                                    <tr>
                                        <td colspan="2" align="right" style="padding-top:8px;">
                                            <input name="printit" value="0" type="hidden">
                                            <input type="hidden" name="ctype" id="ctype" value="metric">
                                            <input type="button" name="x" value="Calculate" onclick="calculateBMI();">
                                            <input type="button" value="Clear" onclick="clearForm(document.calform);">
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </form>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<div class="rightresult">
    <h2 class="h2result">Result
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/save.svg" width="19" height="20" title="Save this calculation" style="float:right;padding-top:3px;cursor: pointer;" onclick="saveCalResult();">
    </h2>
    
    <div id="bmi-result" class="bigtext" style="margin-top:5px;">
        <b>BMI = 20.1 kg/m<sup>2</sup></b> &nbsp; (<font color="green"><b>Normal</b></font>)
    </div>
    
    <div id="bmi-chart" style="padding-top:10px;text-align:center;">
        <!-- BMI Chart SVG will be inserted here -->
        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="300px" height="163px" viewBox="0 0 300 163">
            <g transform="translate(18,18)" style="font-family:arial,helvetica,sans-serif;font-size: 12px;">
                <defs>
                    <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto">
                        <polygon points="0 0, 10 3.5, 0 7"></polygon>
                    </marker>
                </defs>
                
                <!-- BMI ranges as colored arcs -->
                <path d="M0 140 A140 140, 0, 0, 1, 6.9 96.7 L140 140 Z" fill="#bc2020"></path>
                <path d="M6.9 96.7 A140 140, 0, 0, 1, 12.1 83.1 L140 140 Z" fill="#d38888"></path>
                <path d="M12.1 83.1 A140 140, 0, 0, 1, 22.6 63.8 L140 140 Z" fill="#ffe400"></path>
                <path d="M22.6 63.8 A140 140, 0, 0, 1, 96.7 6.9 L140 140 Z" fill="#008137"></path>
                <path d="M96.7 6.9 A140 140, 0, 0, 1, 169.1 3.1 L140 140 Z" fill="#ffe400"></path>
                <path d="M169.1 3.1 A140 140, 0, 0, 1, 233.7 36 L140 140 Z" fill="#d38888"></path>
                <path d="M233.7 36 A140 140, 0, 0, 1, 273.1 96.7 L140 140 Z" fill="#bc2020"></path>
                <path d="M273.1 96.7 A140 140, 0, 0, 1, 280 140 L140 140 Z" fill="#8a0101"></path>
                
                <!-- Inner white circle -->
                <path d="M45 140 A90 90, 0, 0, 1, 230 140 Z" fill="#fff"></path>
                
                <!-- Center point -->
                <circle cx="140" cy="140" r="5" fill="#666"></circle>
                
                <!-- BMI scale numbers -->
                <g style="paint-order: stroke;stroke: #fff;stroke-width: 2px;">
                    <text x="25" y="111" transform="rotate(-72, 25, 111)">16</text>
                    <text x="30" y="96" transform="rotate(-66, 30, 96)">17</text>
                    <text x="35" y="83" transform="rotate(-57, 35, 83)">18.5</text>
                    <text x="97" y="29" transform="rotate(-18, 97, 29)">25</text>
                    <text x="157" y="20" transform="rotate(12, 157, 20)">30</text>
                    <text x="214" y="45" transform="rotate(42, 214, 45)">35</text>
                    <text x="252" y="95" transform="rotate(72, 252, 95)">40</text>
                </g>
                
                <!-- BMI indicator arrow -->
                <line id="bmi-arrow" x1="140" y1="140" x2="65" y2="140" stroke="#666" stroke-width="2" marker-end="url(#arrowhead)">
                    <animateTransform attributeName="transform" attributeType="XML" type="rotate" from="0 140 140" to="42.6 140 140" dur="1s" fill="freeze" repeatCount="1"></animateTransform>
                </line>
                
                <!-- BMI value display -->
                <text id="bmi-value-display" x="67" y="120" style="font-size: 30px;font-weight:bold;color:#000;">BMI = 20.1</text>
            </g>
        </svg>
    </div>
    
    <ul id="bmi-details" style="margin-left:8px;padding-left:8px;">
        <li>Healthy BMI range: 18.5 kg/m<sup>2</sup> - 25 kg/m<sup>2</sup></li>
        <li>Healthy weight for the height: 59.9 kg - 81 kg</li>
        <li>BMI Prime: 0.8</li>
        <li>Ponderal Index: 11.1 kg/m<sup>3</sup></li>
    </ul>
</div>

<div id="clear"></div>

<script>
function popMenu(inval, insubmit) {
    var htmlVal = "";
    if (inval == "metric") {
        htmlVal = htmlVal + "<li><a href=\"#\" onclick=\"return popMenu('standard',1);\">US Units</a></li> <li id='menuon'><a href=\"#\" onclick=\"return popMenu('metric',1);\">Metric Units</a></li> <li><a href=\"#\" onclick=\"return popMenu('other',0);\">Other Units</a></li>";
        document.getElementById("ctype").value = "metric";
        document.getElementById("standardheightweight").style.display = 'none';
        document.getElementById("metricheightweight").style.display = 'block';
        htmlVal = "<ul>" + htmlVal + "</ul>";
        document.getElementById("ucframe").innerHTML = "";
        if (insubmit == 1) calculateBMI();
    } else if (inval == "standard") {
        htmlVal = htmlVal + "<li id='menuon'><a href=\"#\" onclick=\"return popMenu('standard',1);\">US Units</a></li> <li><a href=\"#\" onclick=\"return popMenu('metric',1);\">Metric Units</a></li> <li><a href=\"#\" onclick=\"return popMenu('other',0);\">Other Units</a></li>";
        document.getElementById("ctype").value = "standard";
        document.getElementById("standardheightweight").style.display = 'block';
        document.getElementById("metricheightweight").style.display = 'none';
        htmlVal = "<ul>" + htmlVal + "</ul>";
        document.getElementById("ucframe").innerHTML = "";
        if (insubmit == 1) calculateBMI();
    } else {
        htmlVal = document.getElementById("topmenu").innerHTML;
        document.getElementById("ucframe").innerHTML = "<iframe src=\"/converter/converter.php?type=\" style=\"overflow:hidden;width:100%\" width=\"100%\" height=\"238\" frameborder=\"NO\" scrolling=\"NO\" allowTransparency=\"true\" ></IFRAME>";
    }
    document.getElementById("topmenu").innerHTML = htmlVal;
    return false;
}

function calculateBMI() {
    var age = parseFloat(document.getElementById('cage').value);
    var gender = document.querySelector('input[name="csex"]:checked').value;
    var unitType = document.getElementById('ctype').value;
    var height, weight;
    
    if (unitType === 'metric') {
        height = parseFloat(document.getElementById('cheightmeter').value);
        weight = parseFloat(document.getElementById('ckg').value);
    } else {
        var feet = parseFloat(document.getElementById('cheightfeet').value);
        var inches = parseFloat(document.getElementById('cheightinch').value);
        height = (feet * 12 + inches) * 2.54; // Convert to cm
        weight = parseFloat(document.getElementById('cpound').value) * 0.453592; // Convert to kg
    }
    
    // Validate inputs
    if (isNaN(age) || isNaN(height) || isNaN(weight) || age < 2 || age > 120 || height <= 0 || weight <= 0) {
        alert('Please enter valid values for all fields.');
        return;
    }
    
    // Calculate BMI
    var heightM = height / 100; // Convert cm to meters
    var bmi = weight / (heightM * heightM);
    
    // Determine BMI category
    var category = '';
    var color = '';
    if (bmi < 16) {
        category = 'Severe Thinness';
        color = '#bc2020';
    } else if (bmi < 17) {
        category = 'Moderate Thinness';
        color = '#d38888';
    } else if (bmi < 18.5) {
        category = 'Mild Thinness';
        color = '#ffe400';
    } else if (bmi < 25) {
        category = 'Normal';
        color = '#008137';
    } else if (bmi < 30) {
        category = 'Overweight';
        color = '#ffe400';
    } else if (bmi < 35) {
        category = 'Obese Class I';
        color = '#d38888';
    } else if (bmi < 40) {
        category = 'Obese Class II';
        color = '#bc2020';
    } else {
        category = 'Obese Class III';
        color = '#8a0101';
    }
    
    // Calculate healthy weight range
    var healthyMin = 18.5 * (heightM * heightM);
    var healthyMax = 25 * (heightM * heightM);
    
    // Calculate BMI Prime
    var bmiPrime = bmi / 25;
    
    // Calculate Ponderal Index
    var ponderalIndex = weight / (heightM * heightM * heightM);
    
    // Update result display
    document.getElementById('bmi-result').innerHTML = 
        '<b>BMI = ' + bmi.toFixed(1) + ' kg/m<sup>2</sup></b> &nbsp; (<font color="' + color + '"><b>' + category + '</b></font>)';
    
    document.getElementById('bmi-value-display').textContent = 'BMI = ' + bmi.toFixed(1);
    
    // Update details
    var detailsHtml = '';
    detailsHtml += '<li>Healthy BMI range: 18.5 kg/m<sup>2</sup> - 25 kg/m<sup>2</sup></li>';
    detailsHtml += '<li>Healthy weight for the height: ' + healthyMin.toFixed(1) + ' kg - ' + healthyMax.toFixed(1) + ' kg</li>';
    detailsHtml += '<li>BMI Prime: ' + bmiPrime.toFixed(1) + '</li>';
    detailsHtml += '<li>Ponderal Index: ' + ponderalIndex.toFixed(1) + ' kg/m<sup>3</sup></li>';
    
    document.getElementById('bmi-details').innerHTML = detailsHtml;
    
    // Update arrow position (simplified)
    var angle = Math.min(Math.max((bmi - 16) / (40 - 16) * 180, 0), 180);
    var arrow = document.getElementById('bmi-arrow');
    if (arrow) {
        arrow.style.transform = 'rotate(' + angle + 'deg)';
        arrow.style.transformOrigin = '140px 140px';
    }
}

function saveCalResult() {
    alert('Save functionality would be implemented here.');
}

// Initialize with metric units
popMenu("metric", 0);
</script>
