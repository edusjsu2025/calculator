<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog - Calculator.net</title>
    <meta name="description" content="Latest articles and guides about calculators, finance, health, and mathematics.">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<div id="headerout">
    <div id="header">
        <div id="logo">
            <a href="<?php echo home_url(); ?>">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/calculator-white.svg" width="208" height="22" alt="Calculator.net">
            </a>
        </div>
        <div id="login">
            <a href="<?php echo wp_login_url(); ?>">sign in</a>
        </div>
    </div>
</div>

<div id="clear"></div>

<div id="contentout">
    <div id="content">
        <div id="breadcrumbs">
            <a href="<?php echo home_url(); ?>">home</a> / 
            <a href="<?php echo home_url('/blog/'); ?>">blog</a>
        </div>
        
        <div id="printit">
            <a href="#" onclick="window.print(); return false;">Print</a>
        </div>
        
        <h1>📚 Blog & Articles</h1>
        
        <?php
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
        $blog_posts = new WP_Query(array(
            'posts_per_page' => 10,
            'post_status' => 'publish',
            'orderby' => 'date',
            'order' => 'DESC',
            'paged' => $paged
        ));
        
        if ($blog_posts->have_posts()) :
        ?>
        <div class="blog-articles">
            <?php while ($blog_posts->have_posts()) : $blog_posts->the_post(); ?>
            <article class="article-item">
                <h2>
                    <a href="<?php the_permalink(); ?>">
                        <?php the_title(); ?>
                    </a>
                </h2>
                
                <div class="article-meta">
                    <span>📅 <?php echo get_the_date('F j, Y'); ?></span>
                    <span> | 👤 <?php the_author(); ?></span>
                    <?php if (get_the_category()) : ?>
                        <span> | 📂 
                            <?php 
                            $categories = get_the_category();
                            $cat_links = array();
                            foreach($categories as $category) {
                                $cat_links[] = '<a href="' . get_category_link($category->term_id) . '">' . $category->name . '</a>';
                            }
                            echo implode(', ', $cat_links);
                            ?>
                        </span>
                    <?php endif; ?>
                    <?php if (get_comments_number() > 0) : ?>
                        <span> | 💬 <?php echo get_comments_number(); ?> comments</span>
                    <?php endif; ?>
                </div>
                
                <?php if (has_post_thumbnail()) : ?>
                <div class="article-thumbnail" style="margin: 15px 0;">
                    <a href="<?php the_permalink(); ?>">
                        <?php the_post_thumbnail('medium', array('style' => 'max-width: 100%; height: auto; border-radius: 3px;')); ?>
                    </a>
                </div>
                <?php endif; ?>
                
                <div class="article-excerpt">
                    <?php 
                    if (has_excerpt()) {
                        echo get_the_excerpt();
                    } else {
                        echo wp_trim_words(get_the_content(), 50, '...');
                    }
                    ?>
                </div>
                
                <div style="margin-top: 15px;">
                    <a href="<?php the_permalink(); ?>" class="read-more">
                        Read Full Article →
                    </a>
                </div>
            </article>
            <?php endwhile; ?>
        </div>
        
        <!-- Pagination -->
        <div class="pagination" style="text-align: center; margin: 30px 0;">
            <?php
            echo paginate_links(array(
                'total' => $blog_posts->max_num_pages,
                'current' => $paged,
                'prev_text' => '← Previous',
                'next_text' => 'Next →',
                'type' => 'list'
            ));
            ?>
        </div>
        
        <?php 
        wp_reset_postdata();
        else : 
        ?>
        <div class="no-articles">
            <h2>📝 No Articles Yet</h2>
            <p>We haven't published any articles yet. Check back soon for helpful guides and tips about calculators, finance, health, and more!</p>
            <p><a href="<?php echo home_url(); ?>">← Back to Home</a></p>
        </div>
        <?php endif; ?>
        
        <!-- Categories -->
        <div style="margin-top: 40px; padding: 20px; background: #f9f9f9; border-radius: 3px;">
            <h3 style="color: #003366; margin-bottom: 15px;">📂 Article Categories</h3>
            <?php
            $categories = get_categories(array(
                'orderby' => 'count',
                'order' => 'DESC',
                'hide_empty' => true
            ));
            
            if ($categories) :
            ?>
            <div style="display: flex; flex-wrap: wrap; gap: 10px;">
                <?php foreach ($categories as $category) : ?>
                <a href="<?php echo get_category_link($category->term_id); ?>" 
                   style="background: #336699; color: white; padding: 5px 10px; text-decoration: none; border-radius: 3px; font-size: 14px;">
                    <?php echo $category->name; ?> (<?php echo $category->count; ?>)
                </a>
                <?php endforeach; ?>
            </div>
            <?php else : ?>
            <p style="color: #666;">No categories yet.</p>
            <?php endif; ?>
        </div>
    </div>
    
    <div id="right">
        <div style="padding-top:10px; min-height:280px; text-align:center;">
            <div style="width:336px; height:280px; background:#f0f0f0; border:1px solid #ccc; display:flex; align-items:center; justify-content:center;">
                <span style="color:#999;">Advertisement</span>
            </div>
        </div>
        
        <div id="othercalc">
            <div id="octitle">
                <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>">Fitness and Health Calculators</a>
            </div>
            <div id="occontent">
                <a href="<?php echo home_url('/bmi-calculator/'); ?>">BMI</a>
                <a href="<?php echo home_url('/calorie-calculator/'); ?>">Calorie</a>
                <a href="<?php echo home_url('/body-fat-calculator/'); ?>">Body Fat</a>
                <a href="<?php echo home_url('/bmr-calculator/'); ?>">BMR</a>
                <a href="<?php echo home_url('/macro-calculator/'); ?>">Macro</a>
                <a href="<?php echo home_url('/ideal-weight-calculator/'); ?>">Ideal Weight</a>
                <a href="<?php echo home_url('/pregnancy-calculator/'); ?>">Pregnancy</a>
                <a href="<?php echo home_url('/pregnancy-weight-gain-calculator/'); ?>">Pregnancy Weight Gain</a>
                <a href="<?php echo home_url('/pregnancy-conception-calculator/'); ?>">Pregnancy Conception</a>
                <a href="<?php echo home_url('/due-date-calculator/'); ?>">Due Date</a>
                <a href="<?php echo home_url('/pace-calculator/'); ?>">Pace</a>
                <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>">More Fitness and Health Calculators</a>
            </div>
            <div id="ocother">
                <a href="<?php echo home_url('/financial-calculator/'); ?>">Financial</a> |
                <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>">Fitness and Health</a> |
                <a href="<?php echo home_url('/math-calculator/'); ?>">Math</a> |
                <a href="<?php echo home_url('/other-calculator/'); ?>">Other</a>
            </div>
        </div>
    </div>
</div>

<div id="clear"></div>

<div id="footer">
    <div id="footerin">
        <div id="footernav">
            <a href="<?php echo home_url('/about-us/'); ?>">about us</a> | 
            <a href="<?php echo home_url('/sitemap/'); ?>">sitemap</a> | 
            <a href="<?php echo home_url('/terms-of-use/'); ?>">terms of use</a> | 
            <a href="<?php echo home_url('/privacy-policy/'); ?>">privacy policy</a> &nbsp; 
            © 2008 - <?php echo date('Y'); ?> <a href="<?php echo home_url(); ?>">calculator.net</a>
        </div>
    </div>
</div>

<!-- Top Navigation (absolute positioned) -->
<div class="topNavAbs">
    <a href="<?php echo home_url('/financial-calculator/'); ?>" data-category="financial">Financial</a>
    <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>" data-category="fitness">Fitness &amp; Health</a>
    <a href="<?php echo home_url('/math-calculator/'); ?>" data-category="math">Math</a>
    <a href="<?php echo home_url('/other-calculator/'); ?>" data-category="other">Other</a>
</div>

<?php wp_footer(); ?>

<script>
// Top navigation click handler
document.addEventListener('DOMContentLoaded', function() {
    const navLinks = document.querySelectorAll('.topNavAbs a');
    
    navLinks.forEach(function(link) {
        link.addEventListener('click', function(e) {
            const category = this.getAttribute('data-category');
            if (category) {
                localStorage.setItem('activeNavCategory', category);
            }
            
            navLinks.forEach(function(l) {
                l.classList.remove('topNavOn');
            });
            
            this.classList.add('topNavOn');
        });
    });
    
    // Restore active state from localStorage
    const storedCategory = localStorage.getItem('activeNavCategory');
    if (storedCategory) {
        const targetLink = document.querySelector(`.topNavAbs a[data-category="${storedCategory}"]`);
        if (targetLink) {
            targetLink.classList.add('topNavOn');
        }
    }
});
</script>

</body>
</html>
