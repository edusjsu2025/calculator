<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>图片测试页面 - Calculator.net</title>
    <meta name="description" content="测试主题中所有图片是否正确显示">
    <?php wp_head(); ?>
    <style>
        .image-test-section {
            margin: 20px 0;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background: #f9f9f9;
        }
        .image-test-section h3 {
            color: #003366;
            margin-bottom: 15px;
        }
        .image-container {
            margin: 10px 0;
            padding: 10px;
            background: white;
            border: 1px solid #ccc;
            text-align: center;
        }
        .image-info {
            font-size: 14px;
            color: #666;
            margin-top: 10px;
        }
        .error {
            color: red;
            font-weight: bold;
        }
        .success {
            color: green;
            font-weight: bold;
        }
    </style>
</head>
<body <?php body_class(); ?>>

<div id="headerout">
    <div id="header">
        <div id="logo">
            <a href="<?php echo home_url(); ?>">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/calculator-white.svg" width="208" height="22" alt="Calculator.net">
            </a>
        </div>
        <div id="login">
            <a href="<?php echo wp_login_url(); ?>">sign in</a>
        </div>
    </div>
</div>

<div id="clear"></div>

<div id="contentout">
    <div id="content">
        <div id="breadcrumbs" itemscope itemtype="https://schema.org/BreadcrumbList">
            <span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
                <a href="<?php echo home_url(); ?>" itemprop="item"><span itemprop="name">home</span></a>
                <meta itemprop="position" content="1">
            </span> / 
            <span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
                <a href="<?php the_permalink(); ?>" itemprop="item"><span itemprop="name">image test</span></a>
                <meta itemprop="position" content="2">
            </span>
        </div>
        
        <div id="printit">
            <a href="#" onclick="window.print(); return false;">Print</a>
        </div>
        
        <h1>🖼️ 图片测试页面</h1>
        
        <p>此页面用于测试主题中所有图片是否正确显示。如果您看到红色错误信息，说明图片路径有问题。</p>
        
        <div class="image-test-section">
            <h3>1. Logo测试 (Header中的Logo)</h3>
            <div class="image-container">
                <p>Header中的Logo应该已经显示在页面顶部。如果看不到，说明路径有问题。</p>
                <div class="image-info">
                    路径: <?php echo get_template_directory_uri(); ?>/assets/images/calculator-white.svg<br>
                    文件存在: <?php echo file_exists(get_template_directory() . '/assets/images/calculator-white.svg') ? '<span class="success">是</span>' : '<span class="error">否</span>'; ?>
                </div>
            </div>
        </div>
        
        <div class="image-test-section">
            <h3>2. 短代码测试</h3>
            <div class="image-container">
                <h4>Calculator Logo (使用短代码)</h4>
                <?php echo do_shortcode('[theme_image src="calculator-white.svg" alt="Calculator Logo" width="208" height="22"]'); ?>
                <div class="image-info">短代码: [theme_image src="calculator-white.svg" alt="Calculator Logo" width="208" height="22"]</div>
            </div>
            
            <div class="image-container">
                <h4>BMI Chart (使用短代码)</h4>
                <?php echo do_shortcode('[theme_image src="bmi-chart.gif" alt="BMI Chart" width="300"]'); ?>
                <div class="image-info">短代码: [theme_image src="bmi-chart.gif" alt="BMI Chart" width="300"]</div>
            </div>
            
            <div class="image-container">
                <h4>Save Icon (使用短代码)</h4>
                <?php echo do_shortcode('[theme_image src="save.svg" alt="Save Icon" width="19" height="20"]'); ?>
                <div class="image-info">短代码: [theme_image src="save.svg" alt="Save Icon" width="19" height="20"]</div>
            </div>
        </div>
        
        <div class="image-test-section">
            <h3>3. 直接HTML测试 (会被自动修复)</h3>
            <div class="image-container">
                <h4>使用相对路径 assets/images/</h4>
                <img src="assets/images/insm.svg" width="300" height="35" alt="Instruction Banner">
                <div class="image-info">HTML: &lt;img src="assets/images/insm.svg"&gt;</div>
            </div>
            
            <div class="image-container">
                <h4>使用相对路径 images/</h4>
                <img src="images/icon.png" width="32" height="32" alt="Site Icon">
                <div class="image-info">HTML: &lt;img src="images/icon.png"&gt;</div>
            </div>
        </div>
        
        <div class="image-test-section">
            <h3>4. WordPress函数测试</h3>
            <div class="image-container">
                <h4>使用 get_theme_image_url() 函数</h4>
                <img src="<?php echo get_theme_image_url('calculator-white.svg'); ?>" width="208" height="22" alt="Calculator Logo">
                <div class="image-info">
                    函数: get_theme_image_url('calculator-white.svg')<br>
                    结果: <?php echo get_theme_image_url('calculator-white.svg'); ?>
                </div>
            </div>
            
            <div class="image-container">
                <h4>使用 get_theme_image() 函数</h4>
                <?php echo get_theme_image('bmi-chart.gif', 'BMI Chart', '200', '', 'test-image'); ?>
                <div class="image-info">函数: get_theme_image('bmi-chart.gif', 'BMI Chart', '200', '', 'test-image')</div>
            </div>
        </div>
        
        <div class="image-test-section">
            <h3>5. 文件存在性检查</h3>
            <div class="image-container">
                <?php
                $images = array(
                    'calculator-white.svg' => 'Calculator Logo',
                    'insm.svg' => 'Instruction Banner',
                    'save.svg' => 'Save Icon',
                    'bmi-chart.gif' => 'BMI Chart',
                    'icon.png' => 'Site Icon'
                );
                
                foreach ($images as $filename => $description) {
                    $file_path = get_template_directory() . '/assets/images/' . $filename;
                    $file_url = get_template_directory_uri() . '/assets/images/' . $filename;
                    $exists = file_exists($file_path);
                    
                    echo '<div style="margin: 5px 0; padding: 5px; background: ' . ($exists ? '#e8f5e8' : '#ffe8e8') . ';">';
                    echo '<strong>' . $description . ' (' . $filename . ')</strong><br>';
                    echo '文件存在: ' . ($exists ? '<span class="success">是</span>' : '<span class="error">否</span>') . '<br>';
                    echo '文件路径: ' . $file_path . '<br>';
                    echo '访问URL: <a href="' . $file_url . '" target="_blank">' . $file_url . '</a>';
                    echo '</div>';
                }
                ?>
            </div>
        </div>
        
        <div class="image-test-section">
            <h3>6. 调试信息</h3>
            <div class="image-container">
                <div style="text-align: left; font-family: monospace; font-size: 12px;">
                    <strong>主题目录:</strong> <?php echo get_template_directory(); ?><br>
                    <strong>主题URL:</strong> <?php echo get_template_directory_uri(); ?><br>
                    <strong>网站URL:</strong> <?php echo home_url(); ?><br>
                    <strong>WordPress版本:</strong> <?php echo get_bloginfo('version'); ?><br>
                    <strong>PHP版本:</strong> <?php echo PHP_VERSION; ?><br>
                    <strong>当前主题:</strong> <?php echo wp_get_theme()->get('Name'); ?>
                </div>
            </div>
        </div>
        
        <div class="image-test-section">
            <h3>7. JavaScript图片加载检查</h3>
            <div class="image-container">
                <div id="js-check-results">正在检查图片加载状态...</div>
            </div>
        </div>
        
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            const images = document.querySelectorAll('img');
            let loadedCount = 0;
            let totalCount = images.length;
            let results = [];
            
            images.forEach((img, index) => {
                if (img.complete && img.naturalHeight !== 0) {
                    loadedCount++;
                    results.push(`✅ 图片 ${index + 1}: ${img.alt || '无alt'} - 加载成功`);
                } else {
                    results.push(`❌ 图片 ${index + 1}: ${img.alt || '无alt'} - 加载失败 (${img.src})`);
                    img.style.border = '2px solid red';
                    img.title = '加载失败: ' + img.src;
                }
            });
            
            const resultDiv = document.getElementById('js-check-results');
            resultDiv.innerHTML = `
                <strong>图片加载统计: ${loadedCount}/${totalCount} 成功</strong><br><br>
                ${results.join('<br>')}
            `;
        });
        </script>
    </div>
    
    <div id="right">
        <div style="padding-top:10px; min-height:280px; text-align:center;">
            <div style="width:336px; height:280px; background:#f0f0f0; border:1px solid #ccc; display:flex; align-items:center; justify-content:center;">
                <span style="color:#999;">Advertisement</span>
            </div>
        </div>
        
        <form name="calcSearchForm" onsubmit="calcSearch(); return false;" autocomplete="off">
            <table align="center" id="searchbox">
                <tbody>
                    <tr>
                        <td>
                            <input type="text" name="calcSearchTerm" id="calcSearchTerm" class="inlongest" onkeyup="return calcSearch();">
                        </td>
                        <td>
                            <span id="bluebtn" onclick="return calcSearch();">Search</span>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div id="calcSearchOut"></div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </form>
        
        <div id="othercalc">
            <div id="octitle">
                <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>">Fitness and Health Calculators</a>
            </div>
            <div id="occontent">
                <a href="<?php echo home_url('/bmi-calculator/'); ?>">BMI</a>
                <a href="<?php echo home_url('/calorie-calculator/'); ?>">Calorie</a>
                <a href="<?php echo home_url('/body-fat-calculator/'); ?>">Body Fat</a>
                <a href="<?php echo home_url('/bmr-calculator/'); ?>">BMR</a>
                <a href="<?php echo home_url('/macro-calculator/'); ?>">Macro</a>
                <a href="<?php echo home_url('/ideal-weight-calculator/'); ?>">Ideal Weight</a>
                <a href="<?php echo home_url('/pregnancy-calculator/'); ?>">Pregnancy</a>
                <a href="<?php echo home_url('/pregnancy-weight-gain-calculator/'); ?>">Pregnancy Weight Gain</a>
                <a href="<?php echo home_url('/pregnancy-conception-calculator/'); ?>">Pregnancy Conception</a>
                <a href="<?php echo home_url('/due-date-calculator/'); ?>">Due Date</a>
                <a href="<?php echo home_url('/pace-calculator/'); ?>">Pace</a>
                <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>">More Fitness and Health Calculators</a>
            </div>
            <div id="ocother">
                <a href="<?php echo home_url('/financial-calculator/'); ?>">Financial</a> | 
                <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>">Fitness and Health</a> | 
                <a href="<?php echo home_url('/math-calculator/'); ?>">Math</a> | 
                <a href="<?php echo home_url('/other-calculator/'); ?>">Other</a>
            </div>
        </div>
    </div>
</div>

<div id="clear"></div>

<div id="footer">
    <div id="footerin">
        <div id="footernav">
            <a href="<?php echo home_url('/about-us/'); ?>">about us</a> | 
            <a href="<?php echo home_url('/sitemap/'); ?>">sitemap</a> | 
            <a href="<?php echo home_url('/terms-of-use/'); ?>">terms of use</a> | 
            <a href="<?php echo home_url('/privacy-policy/'); ?>">privacy policy</a> &nbsp; 
            © 2008 - <?php echo date('Y'); ?> <a href="<?php echo home_url(); ?>">calculator.net</a>
        </div>
    </div>
</div>

<div class="topNavAbs">
    <a href="<?php echo home_url('/financial-calculator/'); ?>" data-category="financial">Financial</a>
    <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>" data-category="fitness">Fitness &amp; Health</a>
    <a href="<?php echo home_url('/math-calculator/'); ?>" data-category="math">Math</a>
    <a href="<?php echo home_url('/other-calculator/'); ?>" data-category="other">Other</a>
</div>

<?php wp_footer(); ?>

<script>
function calcSearch() {
    const searchTerm = document.getElementById('calcSearchTerm').value.toLowerCase().trim();
    const searchOut = document.getElementById('calcSearchOut');
    
    if (searchTerm.length === 0) {
        searchOut.innerHTML = '';
        return false;
    }
    
    const calculators = [
        {name: 'BMI Calculator', url: '<?php echo home_url("/bmi-calculator/"); ?>'},
        {name: 'Image Test', url: '<?php echo home_url("/image-test/"); ?>'}
    ];
    
    const results = calculators.filter(calc => 
        calc.name.toLowerCase().includes(searchTerm)
    );
    
    let html = '';
    if (results.length > 0) {
        results.forEach(calc => {
            html += `<div><a href="${calc.url}">${calc.name}</a></div>`;
        });
    } else {
        html = `<div>No calculator matches "${searchTerm}".</div>`;
    }
    
    searchOut.innerHTML = html;
    return false;
}
</script>

</body>
</html>
