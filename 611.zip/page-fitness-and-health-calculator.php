<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fitness and Health Calculators</title>
    <meta name="description" content="Free fitness and health calculators including BMI, calorie, body fat, and ideal weight calculators.">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<div id="headerout">
    <div id="header">
        <div id="logo">
            <a href="<?php echo home_url(); ?>">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/calculator-white.svg" width="208" height="22" alt="Calculator.net">
            </a>
        </div>
        <div id="login">
            <a href="<?php echo wp_login_url(); ?>">sign in</a>
        </div>
    </div>
</div>

<div id="clear"></div>

<div id="contentout">
    <div id="content">
        <div id="breadcrumbs">
            <a href="<?php echo home_url(); ?>">home</a> / 
            <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>">fitness &amp; health calculators</a>
        </div>
        
        <div id="printit">
            <a href="#" onclick="window.print(); return false;">Print</a>
        </div>
        
        <h1>Fitness and Health Calculators</h1>
        
        <div class="calculator-categories">
            <div class="calculator-category">
                <h2>Popular Fitness and Health Calculators</h2>
                <div class="calculator-list">
                    <a href="<?php echo home_url('/bmi-calculator/'); ?>">BMI Calculator</a>
                    <a href="<?php echo home_url('/calorie-calculator/'); ?>">Calorie Calculator</a>
                    <a href="<?php echo home_url('/body-fat-calculator/'); ?>">Body Fat Calculator</a>
                    <a href="<?php echo home_url('/bmr-calculator/'); ?>">BMR Calculator</a>
                    <a href="<?php echo home_url('/macro-calculator/'); ?>">Macro Calculator</a>
                    <a href="<?php echo home_url('/ideal-weight-calculator/'); ?>">Ideal Weight Calculator</a>
                    <a href="<?php echo home_url('/pregnancy-calculator/'); ?>">Pregnancy Calculator</a>
                    <a href="<?php echo home_url('/pregnancy-weight-gain-calculator/'); ?>">Pregnancy Weight Gain Calculator</a>
                    <a href="<?php echo home_url('/pregnancy-conception-calculator/'); ?>">Pregnancy Conception Calculator</a>
                    <a href="<?php echo home_url('/due-date-calculator/'); ?>">Due Date Calculator</a>
                    <a href="<?php echo home_url('/pace-calculator/'); ?>">Pace Calculator</a>
                </div>
            </div>
        </div>
        
        <p>Our fitness and health calculators help you track your health metrics, plan your diet, and monitor your fitness progress. All calculators are based on scientifically proven formulas and are completely free to use.</p>
    </div>
    
    <div id="right">
        <div style="padding-top:10px; min-height:280px; text-align:center;">
            <div style="width:336px; height:280px; background:#f0f0f0; border:1px solid #ccc; display:flex; align-items:center; justify-content:center;">
                <span style="color:#999;">Advertisement</span>
            </div>
        </div>
        
        <div id="othercalc">
            <div id="octitle">
                <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>">Fitness and Health Calculators</a>
            </div>
            <div id="occontent">
                <a href="<?php echo home_url('/bmi-calculator/'); ?>">BMI</a>
                <a href="<?php echo home_url('/calorie-calculator/'); ?>">Calorie</a>
                <a href="<?php echo home_url('/body-fat-calculator/'); ?>">Body Fat</a>
                <a href="<?php echo home_url('/bmr-calculator/'); ?>">BMR</a>
                <a href="<?php echo home_url('/macro-calculator/'); ?>">Macro</a>
                <a href="<?php echo home_url('/ideal-weight-calculator/'); ?>">Ideal Weight</a>
                <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>">More Fitness and Health Calculators</a>
            </div>
            <div id="ocother">
                <a href="<?php echo home_url('/financial-calculator/'); ?>">Financial</a> | 
                <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>">Fitness and Health</a> | 
                <a href="<?php echo home_url('/math-calculator/'); ?>">Math</a> | 
                <a href="<?php echo home_url('/other-calculator/'); ?>">Other</a>
            </div>
        </div>
    </div>
</div>

<div id="clear"></div>

<div id="footer">
    <div id="footerin">
        <div id="footernav">
            <a href="<?php echo home_url('/about-us/'); ?>">about us</a> | 
            <a href="<?php echo home_url('/sitemap/'); ?>">sitemap</a> | 
            <a href="<?php echo home_url('/terms-of-use/'); ?>">terms of use</a> | 
            <a href="<?php echo home_url('/privacy-policy/'); ?>">privacy policy</a> &nbsp; 
            © 2008 - <?php echo date('Y'); ?> <a href="<?php echo home_url(); ?>">calculator.net</a>
        </div>
    </div>
</div>

<!-- Top Navigation (absolute positioned) -->
<div class="topNavAbs">
    <a href="<?php echo home_url('/financial-calculator/'); ?>" data-category="financial">Financial</a>
    <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>" class="topNavOn" data-category="fitness">Fitness &amp; Health</a>
    <a href="<?php echo home_url('/math-calculator/'); ?>" data-category="math">Math</a>
    <a href="<?php echo home_url('/other-calculator/'); ?>" data-category="other">Other</a>
</div>

<?php wp_footer(); ?>

<script>
// Top navigation click handler
document.addEventListener('DOMContentLoaded', function() {
    const navLinks = document.querySelectorAll('.topNavAbs a');
    
    navLinks.forEach(function(link) {
        link.addEventListener('click', function(e) {
            const category = this.getAttribute('data-category');
            if (category) {
                localStorage.setItem('activeNavCategory', category);
            }
            
            navLinks.forEach(function(l) {
                l.classList.remove('topNavOn');
            });
            
            this.classList.add('topNavOn');
        });
    });
    
    // Ensure fitness category is active
    const fitnessLink = document.querySelector('.topNavAbs a[data-category="fitness"]');
    if (fitnessLink && !fitnessLink.classList.contains('topNavOn')) {
        fitnessLink.classList.add('topNavOn');
        localStorage.setItem('activeNavCategory', 'fitness');
    }
});
</script>

</body>
</html>
