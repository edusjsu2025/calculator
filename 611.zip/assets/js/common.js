/*
Calculator.net Common JavaScript Functions
*/

function gObj(obj) {
    return document.getElementById(obj);
}

function trimAll(sString) {
    return sString.trim();
}

function isNumber(val) {
    val = val + "";
    if (val.length < 1) return false;
    if (isNaN(val)) {
        return false;
    } else {
        return true;
    }
}

function isInteger(val) {
    if (isNumber(val)) {
        return val % 1 === 0;
    } else {
        return false;
    }
}

function formatAsMoney(num) {
    return formatAsMoneyFull(num, 1);
}

function formatAsMoneyFull(num, hascents) {
    num = num.toString().replace(/\$|\,/g, '');
    if (isNaN(num)) num = "0";
    sign = (num == (num = Math.abs(num)));
    cents = '';
    if (hascents == 1) {
        num = Math.floor(num * 100 + 0.50000000001);
        cents = num % 100;
        num = Math.floor(num / 100).toString();
        if (cents < 10) cents = "0" + cents;
        cents = "." + cents;
    } else {
        num = Math.floor(num + 0.50000000001).toString();
    }
    for (var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++) {
        num = num.substring(0, num.length - (4 * i + 3)) + ',' + num.substring(num.length - (4 * i + 3));
    }
    return (((sign) ? '' : '-') + '$' + num + cents);
}

function clearForm(formObj) {
    var allElements = formObj.elements;
    for (i = 0; i < allElements.length; i++) {
        if (allElements[i].type == 'text' || allElements[i].type == 'number' || allElements[i].type == 'date' || allElements[i].type == 'textarea') {
            allElements[i].value = '';
        }
    }
}

function formatNum(inNum) {
    outStr = "" + inNum;
    inNum = parseFloat(outStr);
    if ((outStr.length) > 10) {
        outStr = "" + inNum.toPrecision(10);
    }
    if (outStr.indexOf(".") > -1) {
        while (outStr.charAt(outStr.length - 1) == "0") {
            outStr = outStr.substr(0, (outStr.length - 1));
        }
        if (outStr.charAt(outStr.length - 1) == ".") {
            outStr = outStr.substr(0, (outStr.length - 1));
        }
        return outStr;
    } else {
        return outStr;
    }
}

function showquickmsg(inStr, isError) {
    if (isError) {
        inStr = "<font color=red>" + inStr + "</font>";
    }
    gObj("coutput").innerHTML = inStr;
}

// Tooltip functionality
var tooltip = function() {
    var id = 'tt';
    var top = 3;
    var left = 3;
    var maxw = 300;
    var speed = 10;
    var timer = 20;
    var endalpha = 95;
    var alpha = 0;
    var tt, t, c, b, h;
    var isvisible = 1;
    var ismobile = false;
    var ie = document.all ? true : false;
    var htmlV = '<div onclick="tooltip.hide(); return false;" style="text-align:right;color:#fff;"><u><b>CLOSE</b></u></div>';
    
    return {
        show: function(v, ism) {
            if (ism == 'm') {
                ismobile = true;
            } else {
                ismobile = false;
            }
            if (tt == null) {
                tt = document.createElement('div');
                tt.setAttribute('id', id);
                document.body.appendChild(tt);
                tt.style.opacity = 0;
                tt.style.filter = 'alpha(opacity=0)';
                document.onmousemove = this.pos;
            }
            isvisible = 0;
            tt.style.display = 'block';
            tt.innerHTML = v;
            if (ismobile) tt.innerHTML = v + htmlV;
            if (ie) {
                tt.style.width = tt.offsetWidth;
            }
            if (tt.offsetWidth > maxw) {
                tt.style.width = maxw + 'px';
            }
            if (ismobile) tt.style.width = '';
            h = parseInt(tt.offsetHeight) + top;
            clearInterval(tt.timer);
            tt.timer = setInterval(function() {
                tooltip.fade(1);
            }, timer);
        },
        
        pos: function(e) {
            if (isvisible == 0) {
                var x = 0, y = 0;
                if (document.all) {
                    x = (document.documentElement && document.documentElement.scrollLeft) ? document.documentElement.scrollLeft : document.body.scrollLeft;
                    y = (document.documentElement && document.documentElement.scrollTop) ? document.documentElement.scrollTop : document.body.scrollTop;
                    x += window.event.clientX;
                    y += window.event.clientY;
                } else {
                    x = e.pageX;
                    y = e.pageY;
                }
                if (ismobile) {
                    tt.style.left = "0px";
                } else {
                    tt.style.left = (x + 5) + "px";
                }
                tt.style.top = (y + 10) + "px";
            }
            isvisible = 1;
        },
        
        fade: function(d) {
            var a = alpha;
            if ((a != endalpha && d == 1) || (a != 0 && d == -1)) {
                var i = speed;
                if (endalpha - a < speed && d == 1) {
                    i = endalpha - a;
                } else if (alpha < speed && d == -1) {
                    i = a;
                }
                alpha = a + (i * d);
                tt.style.opacity = alpha * .01;
                tt.style.filter = 'alpha(opacity=' + alpha + ')';
            } else {
                clearInterval(tt.timer);
                if (d == -1) {
                    tt.style.display = 'none';
                }
            }
        },
        
        hide: function() {
            clearInterval(tt.timer);
            isvisible = 0;
            tt.style.display = 'none';
        }
    };
}();

// Input field error messaging
function iptErrmsg(iptInputObj, iptMsg) {
    var iptFName = iptInputObj.name + 'ifcErr';
    var iptErrObj = document.getElementById(iptFName);
    
    if (iptMsg.length < 1) {
        iptInputObj.style.borderColor = "#417516";
        if (iptErrObj !== null) iptErrObj.style.visibility = 'hidden';
    } else {
        if (iptErrObj !== null) {
            iptErrObj.innerHTML = iptMsg;
        } else {
            iptErrObj = document.createElement("div");
            iptErrObj.setAttribute("class", "inputErrMsg");
            iptErrObj.setAttribute("id", iptFName);
            iptErrObj.innerHTML = iptMsg;
            iptInputObj.parentNode.insertBefore(iptErrObj, iptInputObj.nextSibling);
        }
        iptErrObj.style.visibility = 'visible';
        iptInputObj.style.borderColor = "red";
    }
}

// Input field validation
function iptfieldCheck(ifcInput, ifcRequired, ifcType) {
    var ifcIVal = trimAll("" + ifcInput.value);
    var ifcErrMsg = "";
    
    if ("r" == ifcRequired.toLowerCase()) {
        if (ifcIVal.length < 1) {
            ifcInput.addEventListener("blur", function() {
                var ifcrIVal = trimAll("" + ifcInput.value);
                if (ifcrIVal.length < 1) iptErrmsg(ifcInput, "required field");
            });
        }
    }
    
    if (ifcIVal.length > 0) {
        var ifcTemp = ifcType.toLowerCase();
        ifcIVal = ifcIVal.replace(/\t/g, "").replace(/ /g, "").replace(/,/g, "");
        
        if (ifcTemp == "n") {
            if ((!isNumber(ifcIVal)) && (ifcIVal != "-") && (ifcIVal != ".")) {
                ifcErrMsg = "numbers only";
            }
        } else if (ifcTemp == "pn") {
            if (!(isNumber(ifcIVal) && (Number(ifcIVal) > 0))) {
                ifcErrMsg = "positive numbers only";
            }
        } else if (ifcTemp == "pzn") {
            if (!(isNumber(ifcIVal) && (Number(ifcIVal) >= 0))) {
                ifcErrMsg = "non negative numbers only";
            }
        } else if (ifcTemp == "i") {
            if ((!isInteger(ifcIVal)) && (ifcIVal != "-") && (ifcIVal != ".")) {
                ifcErrMsg = "integers only";
            }
        } else if (ifcTemp == "pi") {
            if (!(isInteger(ifcIVal) && (Number(ifcIVal) > 0))) {
                ifcErrMsg = "positive integers only";
            }
        } else if (ifcTemp == "pzi") {
            if (!(isNumber(ifcIVal) && (Number(ifcIVal) >= 0))) {
                ifcErrMsg = "non negative integers only";
            }
        }
    }
    
    iptErrmsg(ifcInput, ifcErrMsg);
}

// Insert comma formatting for numbers
function insertComma(e, l) {
    let t = document.getElementById(e),
        d = t.value.toString().replaceAll(",", ""),
        a = "";
    
    if ("i" == l) {
        a = (d = d.replace(/[^\d.-]/g, "")).toString().split(".")[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    } else if ("d" == l) {
        let g = (d = d.replace(/[^\d.-]/g, "")).toString().split(".");
        a = g[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        if (g.length > 1) {
            a += "." + g[1];
        }
    } else if ("c" == l) {
        a = d.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
    
    t.value = a;
}
