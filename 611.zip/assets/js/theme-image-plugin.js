(function() {
    tinymce.PluginManager.add('theme_image', function(editor, url) {
        editor.addButton('theme_image', {
            title: 'Insert Theme Image',
            icon: 'image',
            onclick: function() {
                editor.windowManager.open({
                    title: 'Insert Theme Image',
                    body: [
                        {
                            type: 'textbox',
                            name: 'src',
                            label: 'Image filename (e.g., bmi-chart.gif)',
                            value: ''
                        },
                        {
                            type: 'textbox',
                            name: 'alt',
                            label: 'Alt text',
                            value: ''
                        },
                        {
                            type: 'textbox',
                            name: 'width',
                            label: 'Width (optional)',
                            value: ''
                        },
                        {
                            type: 'textbox',
                            name: 'height',
                            label: 'Height (optional)',
                            value: ''
                        }
                    ],
                    onsubmit: function(e) {
                        var shortcode = '[theme_image src="' + e.data.src + '"';
                        if (e.data.alt) shortcode += ' alt="' + e.data.alt + '"';
                        if (e.data.width) shortcode += ' width="' + e.data.width + '"';
                        if (e.data.height) shortcode += ' height="' + e.data.height + '"';
                        shortcode += ']';
                        
                        editor.insertContent(shortcode);
                    }
                });
            }
        });
    });
})();
