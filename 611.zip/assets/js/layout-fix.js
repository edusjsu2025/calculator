/**
 * WordPress布局强制修复JavaScript
 * 用于确保侧边栏在任何WordPress环境中都能正确显示
 */

(function() {
    'use strict';
    
    // 强制修复布局的函数
    function forceLayoutFix() {
        // 查找所有可能的contentout容器
        const contentoutSelectors = [
            '#contentout',
            '.wp-block-html #contentout',
            '.wp-block-shortcode #contentout',
            '.elementor-widget-html #contentout',
            '.widget_text #contentout',
            '.textwidget #contentout',
            '.entry-content #contentout',
            '.post-content #contentout',
            '.article-content #contentout'
        ];
        
        contentoutSelectors.forEach(selector => {
            const elements = document.querySelectorAll(selector);
            elements.forEach(element => {
                if (element) {
                    // 强制设置容器样式
                    element.style.setProperty('width', '1100px', 'important');
                    element.style.setProperty('margin-left', 'auto', 'important');
                    element.style.setProperty('margin-right', 'auto', 'important');
                    element.style.setProperty('overflow', 'auto', 'important');
                    element.style.setProperty('display', 'block', 'important');
                    element.style.setProperty('position', 'relative', 'important');
                    element.style.setProperty('clear', 'both', 'important');
                    element.style.setProperty('text-align', 'left', 'important');
                    element.style.setProperty('padding-top', '5px', 'important');
                    
                    // 查找内容区域
                    const contentElement = element.querySelector('#content');
                    if (contentElement) {
                        contentElement.style.setProperty('width', '728px', 'important');
                        contentElement.style.setProperty('float', 'left', 'important');
                        contentElement.style.setProperty('padding', '0px 0px 15px 0px', 'important');
                        contentElement.style.setProperty('box-sizing', 'border-box', 'important');
                        contentElement.style.setProperty('margin', '0', 'important');
                        contentElement.style.setProperty('display', 'block', 'important');
                        contentElement.style.setProperty('position', 'relative', 'important');
                        contentElement.style.setProperty('clear', 'none', 'important');
                    }
                    
                    // 查找侧边栏
                    const rightElement = element.querySelector('#right');
                    if (rightElement) {
                        rightElement.style.setProperty('width', '336px', 'important');
                        rightElement.style.setProperty('float', 'right', 'important');
                        rightElement.style.setProperty('text-align', 'center', 'important');
                        rightElement.style.setProperty('padding', '0px', 'important');
                        rightElement.style.setProperty('box-sizing', 'border-box', 'important');
                        rightElement.style.setProperty('margin', '0', 'important');
                        rightElement.style.setProperty('display', 'block', 'important');
                        rightElement.style.setProperty('position', 'relative', 'important');
                        rightElement.style.setProperty('clear', 'none', 'important');
                        
                        // 修复侧边栏内部元素
                        fixSidebarElements(rightElement);
                    }
                }
            });
        });
        
        // 检查移动端
        checkMobileLayout();
    }
    
    // 修复侧边栏内部元素
    function fixSidebarElements(rightElement) {
        // 修复计算器模块
        const othercalc = rightElement.querySelector('#othercalc');
        if (othercalc) {
            othercalc.style.setProperty('border', 'solid 1px #336699', 'important');
            othercalc.style.setProperty('margin', 'auto', 'important');
            othercalc.style.setProperty('text-align', 'left', 'important');
            othercalc.style.setProperty('width', '332px', 'important');
            othercalc.style.setProperty('background', 'white', 'important');
            othercalc.style.setProperty('display', 'block', 'important');
        }
        
        // 修复搜索框
        const searchbox = rightElement.querySelector('#searchbox');
        if (searchbox) {
            searchbox.style.setProperty('padding-top', '16px', 'important');
            searchbox.style.setProperty('width', '100%', 'important');
            searchbox.style.setProperty('background', 'transparent', 'important');
            
            const searchTable = searchbox.querySelector('table');
            if (searchTable) {
                searchTable.style.setProperty('width', '100%', 'important');
                searchTable.style.setProperty('border-collapse', 'collapse', 'important');
                searchTable.style.setProperty('margin', '0', 'important');
            }
            
            const searchInput = searchbox.querySelector('input[type="text"], .inlongest');
            if (searchInput) {
                searchInput.style.setProperty('width', '100%', 'important');
                searchInput.style.setProperty('padding', '6px 8px', 'important');
                searchInput.style.setProperty('border', '1px solid #044284', 'important');
                searchInput.style.setProperty('border-radius', '2px', 'important');
                searchInput.style.setProperty('font-size', '14px', 'important');
                searchInput.style.setProperty('box-sizing', 'border-box', 'important');
                searchInput.style.setProperty('box-shadow', '1px 1px 2px #666', 'important');
                searchInput.style.setProperty('background-color', '#fff', 'important');
                searchInput.style.setProperty('margin', '0', 'important');
            }
            
            const searchBtn = searchbox.querySelector('#bluebtn');
            if (searchBtn) {
                searchBtn.style.setProperty('border-radius', '2px', 'important');
                searchBtn.style.setProperty('background', '#336699', 'important');
                searchBtn.style.setProperty('padding', '6px 12px', 'important');
                searchBtn.style.setProperty('font-size', '14px', 'important');
                searchBtn.style.setProperty('color', '#fff', 'important');
                searchBtn.style.setProperty('cursor', 'pointer', 'important');
                searchBtn.style.setProperty('border', 'none', 'important');
                searchBtn.style.setProperty('white-space', 'nowrap', 'important');
                searchBtn.style.setProperty('display', 'inline-block', 'important');
                searchBtn.style.setProperty('text-decoration', 'none', 'important');
            }
        }
        
        // 修复广告位
        const adContainer = rightElement.querySelector('div:first-child');
        if (adContainer && adContainer.style.paddingTop) {
            adContainer.style.setProperty('padding-top', '10px', 'important');
            adContainer.style.setProperty('min-height', '280px', 'important');
            adContainer.style.setProperty('text-align', 'center', 'important');
            adContainer.style.setProperty('margin', '0', 'important');
            adContainer.style.setProperty('display', 'block', 'important');
            adContainer.style.setProperty('width', '336px', 'important');
            
            const adDiv = adContainer.querySelector('div');
            if (adDiv) {
                adDiv.style.setProperty('width', '336px', 'important');
                adDiv.style.setProperty('height', '280px', 'important');
                adDiv.style.setProperty('background', '#f0f0f0', 'important');
                adDiv.style.setProperty('border', '1px solid #ccc', 'important');
                adDiv.style.setProperty('display', 'flex', 'important');
                adDiv.style.setProperty('align-items', 'center', 'important');
                adDiv.style.setProperty('justify-content', 'center', 'important');
                adDiv.style.setProperty('margin', '0 auto', 'important');
            }
        }
    }
    
    // 检查移动端布局
    function checkMobileLayout() {
        const isMobile = window.innerWidth <= 720;
        
        if (isMobile) {
            const contentoutElements = document.querySelectorAll('#contentout');
            contentoutElements.forEach(element => {
                element.style.setProperty('width', 'auto', 'important');
                element.style.setProperty('padding', '8px', 'important');
                
                const contentElement = element.querySelector('#content');
                if (contentElement) {
                    contentElement.style.setProperty('width', 'auto', 'important');
                    contentElement.style.setProperty('float', 'none', 'important');
                    contentElement.style.setProperty('padding', '0px', 'important');
                }
                
                const rightElement = element.querySelector('#right');
                if (rightElement) {
                    rightElement.style.setProperty('width', 'auto', 'important');
                    rightElement.style.setProperty('float', 'none', 'important');
                    rightElement.style.setProperty('margin-top', '20px', 'important');
                }
            });
        }
    }
    
    // 在DOM加载完成后执行
    function init() {
        forceLayoutFix();
        
        // 监听窗口大小变化
        window.addEventListener('resize', function() {
            setTimeout(checkMobileLayout, 100);
        });
        
        // 使用MutationObserver监听DOM变化
        if (window.MutationObserver) {
            const observer = new MutationObserver(function(mutations) {
                let shouldFix = false;
                mutations.forEach(function(mutation) {
                    if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                        for (let i = 0; i < mutation.addedNodes.length; i++) {
                            const node = mutation.addedNodes[i];
                            if (node.nodeType === 1 && (
                                node.id === 'contentout' || 
                                node.querySelector && node.querySelector('#contentout')
                            )) {
                                shouldFix = true;
                                break;
                            }
                        }
                    }
                });
                
                if (shouldFix) {
                    setTimeout(forceLayoutFix, 100);
                }
            });
            
            observer.observe(document.body, {
                childList: true,
                subtree: true
            });
        }
        
        // 定期检查布局（作为后备方案）
        setInterval(function() {
            const contentout = document.querySelector('#contentout');
            if (contentout) {
                const computedStyle = window.getComputedStyle(contentout);
                if (computedStyle.width !== '1100px' && window.innerWidth > 720) {
                    forceLayoutFix();
                }
            }
        }, 2000);
    }
    
    // 等待DOM加载完成
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
    
    // 也在window.load事件中执行，确保所有资源加载完成后再次检查
    window.addEventListener('load', function() {
        setTimeout(forceLayoutFix, 500);
    });
    
})();
