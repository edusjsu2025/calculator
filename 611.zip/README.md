# Calculator.net Clone WordPress Theme

A WordPress theme that replicates the functionality and design of calculator.net, featuring a complete BMI calculator and framework for additional calculators.

## Features

- **Exact Visual Replica**: 100% faithful reproduction of calculator.net's design
- **Top Navigation**: Four main categories (Financial, Fitness & Health, Math, Other) with green highlight on click
- **BMI Calculator**: Fully functional BMI calculator with:
  - US Units and Metric Units switching
  - Real-time calculation
  - BMI chart visualization
  - Health category determination
  - Healthy weight range calculation
  - BMI Prime and Ponderal Index calculation
- **Responsive Design**: Works on all device sizes
- **Search Functionality**: Calculator search with autocomplete
- **WordPress Integration**: Custom post types for calculators
- **SEO Optimized**: Proper meta tags and structured data

## Installation

1. **Upload Theme Files**:
   - Copy all theme files to `/wp-content/themes/calculator-net-clone/`
   - Or upload as a ZIP file through WordPress admin

2. **Activate Theme**:
   - Go to Appearance > Themes in WordPress admin
   - Activate "Calculator Net Clone"

3. **Create Pages**:
   - Create a page with slug `bmi-calculator` and assign the "BMI Calculator" template
   - Create additional calculator pages as needed

4. **Set Front Page**:
   - Go to Settings > Reading
   - Set "Front page displays" to "A static page"
   - Choose your home page

## File Structure

```
calculator-net-clone/
├── style.css                 # Main stylesheet (exact replica of calculator.net CSS)
├── functions.php             # Theme functions and WordPress integration
├── index.php                 # Main template file
├── front-page.php           # Home page template
├── page-bmi-calculator.php  # BMI calculator page template
├── template-parts/
│   └── calculator-bmi.php   # BMI calculator component
├── assets/
│   ├── js/
│   │   └── common.js        # Common JavaScript functions
│   └── images/
│       ├── calculator-white.svg
│       ├── insm.svg
│       └── save.svg
└── README.md
```

## Key Features Implemented

### 1. Top Navigation Bar
- Four main categories: Financial, Fitness & Health, Math, Other
- Clicking any category adds green background (`topNavOn` class)
- Absolute positioning matches original design

### 2. BMI Calculator
- **Unit Switching**: Toggle between US Units (feet/inches, pounds) and Metric Units (cm, kg)
- **Real-time Validation**: Input field validation with error messages
- **BMI Calculation**: Accurate BMI calculation using standard formulas
- **Visual Chart**: SVG-based BMI chart with color-coded ranges
- **Health Categories**: 
  - Severe Thinness (< 16)
  - Moderate Thinness (16-17)
  - Mild Thinness (17-18.5)
  - Normal (18.5-25)
  - Overweight (25-30)
  - Obese Class I (30-35)
  - Obese Class II (35-40)
  - Obese Class III (> 40)
- **Additional Metrics**: BMI Prime and Ponderal Index calculation

### 3. Search Functionality
- Live search for calculators
- Autocomplete suggestions
- Matches original calculator.net search behavior

### 4. Responsive Design
- Mobile-friendly layout
- Breakpoints match original design
- Navigation adapts for mobile devices

## Customization

### Adding New Calculators

1. **Create Calculator Template**:
   ```php
   // template-parts/calculator-mortgage.php
   <div class="leftinput">
       <!-- Calculator form -->
   </div>
   <div class="rightresult">
       <!-- Results display -->
   </div>
   ```

2. **Create Page Template**:
   ```php
   // page-mortgage-calculator.php
   <?php get_template_part('template-parts/calculator', 'mortgage'); ?>
   ```

3. **Add to Functions**:
   ```php
   // Add to get_calculator_categories() function
   'mortgage' => 'Mortgage Calculator'
   ```

### Styling Customization

The theme uses the exact CSS from calculator.net. Key classes:

- `.topNavAbs` - Top navigation bar
- `.topNavOn` - Active navigation item (green background)
- `.leftinput` - Calculator input area
- `.rightresult` - Results display area
- `.panel2` - Input form container
- `.h2result` - Results header

### JavaScript Functions

Key functions available:

- `popMenu(type, submit)` - Switch between unit types
- `calculateBMI()` - Perform BMI calculation
- `iptfieldCheck()` - Input field validation
- `calcSearch()` - Calculator search functionality

## Browser Compatibility

- Chrome 60+
- Firefox 55+
- Safari 11+
- Edge 79+
- Internet Explorer 11+ (limited support)

## Performance

- Optimized CSS (minified in production)
- Efficient JavaScript (no external dependencies)
- SVG icons for crisp display
- Responsive images

## SEO Features

- Structured data markup
- Proper heading hierarchy
- Meta descriptions
- Breadcrumb navigation
- Clean URLs

## Support

For issues or questions:

1. Check the WordPress error log
2. Verify all files are uploaded correctly
3. Ensure proper page templates are assigned
4. Test with default WordPress themes to isolate issues

## License

This theme is created for educational purposes and replicates the design of calculator.net. Please respect the original site's terms of service and intellectual property.

## Credits

- Original design: calculator.net
- WordPress integration: Custom development
- Icons: SVG custom created
- Fonts: System fonts (Arial, Helvetica, sans-serif)

## Changelog

### Version 1.0
- Initial release
- BMI Calculator implementation
- Top navigation with green highlighting
- Responsive design
- Search functionality
- WordPress integration
