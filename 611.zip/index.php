<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php wp_title('|', true, 'right'); ?><?php bloginfo('name'); ?></title>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<div id="headerout">
    <div id="header">
        <div id="logo">
            <a href="<?php echo home_url(); ?>">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/calculator-white.svg" width="208" height="22" alt="Calculator.net">
            </a>
        </div>
        <div id="login">
            <a href="<?php echo wp_login_url(); ?>">sign in</a>
        </div>
    </div>
</div>

<div id="clear"></div>

<div id="contentout">
    <div id="content">
        <?php calculator_breadcrumb(); ?>
        
        <div id="printit">
            <a href="#" onclick="window.print(); return false;">Print</a>
        </div>
        
        <h1><?php the_title(); ?></h1>
        
        <?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>
                <?php
                $calculator_type = get_post_meta(get_the_ID(), '_calculator_type', true);
                $calculator_category = get_post_meta(get_the_ID(), '_calculator_category', true);
                
                // Load appropriate calculator template
                switch ($calculator_type) {
                    case 'bmi':
                        get_template_part('template-parts/calculator', 'bmi');
                        break;
                    case 'mortgage':
                        get_template_part('template-parts/calculator', 'mortgage');
                        break;
                    case 'calorie':
                        get_template_part('template-parts/calculator', 'calorie');
                        break;
                    default:
                        get_template_part('template-parts/calculator', 'default');
                        break;
                }
                ?>
                
                <div class="calculator-content">
                    <?php the_content(); ?>
                </div>
                
            <?php endwhile; ?>
        <?php else : ?>
            <!-- Default calculator list if no specific calculator is loaded -->
            <div class="calculator-categories">
                <?php
                $categories = get_calculator_categories();
                foreach ($categories as $key => $category) :
                ?>
                <div class="calculator-category">
                    <h2><a href="<?php echo $category['url']; ?>"><?php echo $category['name']; ?></a></h2>
                    <div class="calculator-list">
                        <?php foreach ($category['calculators'] as $calc_key => $calc_name) : ?>
                            <a href="<?php echo home_url('/' . $calc_key . '-calculator/'); ?>"><?php echo $calc_name; ?></a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <div id="right">
        <div style="padding-top:10px; min-height:280px; text-align:center;">
            <!-- Ad space - exactly like original -->
            <div style="width:336px; height:280px; background:#f0f0f0; border:1px solid #ccc; display:flex; align-items:center; justify-content:center;">
                <span style="color:#999;">Advertisement</span>
            </div>
        </div>

        <form name="calcSearchForm" onsubmit="calcSearch(); return false;" autocomplete="off">
            <table align="center" id="searchbox">
                <tbody>
                    <tr>
                        <td>
                            <input type="text" name="calcSearchTerm" id="calcSearchTerm" class="inlongest" onkeyup="return calcSearch();">
                        </td>
                        <td>
                            <span id="bluebtn" onclick="return calcSearch();">Search</span>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div id="calcSearchOut"></div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </form>

        <div id="othercalc">
            <div id="octitle">
                <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>">Fitness and Health Calculators</a>
            </div>
            <div id="occontent">
                <a href="<?php echo home_url('/bmi-calculator/'); ?>">BMI</a>
                <a href="<?php echo home_url('/calorie-calculator/'); ?>">Calorie</a>
                <a href="<?php echo home_url('/body-fat-calculator/'); ?>">Body Fat</a>
                <a href="<?php echo home_url('/bmr-calculator/'); ?>">BMR</a>
                <a href="<?php echo home_url('/macro-calculator/'); ?>">Macro</a>
                <a href="<?php echo home_url('/ideal-weight-calculator/'); ?>">Ideal Weight</a>
                <a href="<?php echo home_url('/pregnancy-calculator/'); ?>">Pregnancy</a>
                <a href="<?php echo home_url('/pregnancy-weight-gain-calculator/'); ?>">Pregnancy Weight Gain</a>
                <a href="<?php echo home_url('/pregnancy-conception-calculator/'); ?>">Pregnancy Conception</a>
                <a href="<?php echo home_url('/due-date-calculator/'); ?>">Due Date</a>
                <a href="<?php echo home_url('/pace-calculator/'); ?>">Pace</a>
                <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>">More Fitness and Health Calculators</a>
            </div>
            <div id="ocother">
                <a href="<?php echo home_url('/financial-calculator/'); ?>">Financial</a> |
                <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>">Fitness and Health</a> |
                <a href="<?php echo home_url('/math-calculator/'); ?>">Math</a> |
                <a href="<?php echo home_url('/other-calculator/'); ?>">Other</a>
            </div>
        </div>
    </div>
</div>

<div id="clear"></div>

<div id="footer">
    <div id="footerin">
        <div id="footernav">
            <a href="<?php echo home_url('/about-us/'); ?>">about us</a> | 
            <a href="<?php echo home_url('/sitemap/'); ?>">sitemap</a> | 
            <a href="<?php echo home_url('/terms-of-use/'); ?>">terms of use</a> | 
            <a href="<?php echo home_url('/privacy-policy/'); ?>">privacy policy</a> &nbsp; 
            © 2008 - <?php echo date('Y'); ?> <a href="<?php echo home_url(); ?>">calculator.net</a>
        </div>
    </div>
</div>

<!-- Top Navigation (absolute positioned) -->
<div class="topNavAbs">
    <?php
    $current_category = get_current_page_category();
    ?>
    <a href="<?php echo home_url('/financial-calculator/'); ?>"
       <?php echo ($current_category === 'financial') ? 'class="topNavOn"' : ''; ?>
       data-category="financial">Financial</a>
    <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>"
       <?php echo ($current_category === 'fitness') ? 'class="topNavOn"' : ''; ?>
       data-category="fitness">Fitness &amp; Health</a>
    <a href="<?php echo home_url('/math-calculator/'); ?>"
       <?php echo ($current_category === 'math') ? 'class="topNavOn"' : ''; ?>
       data-category="math">Math</a>
    <a href="<?php echo home_url('/other-calculator/'); ?>"
       <?php echo ($current_category === 'other') ? 'class="topNavOn"' : ''; ?>
       data-category="other">Other</a>
</div>

<?php wp_footer(); ?>

<script>
// Top navigation click handler to add green background
document.addEventListener('DOMContentLoaded', function() {
    const navLinks = document.querySelectorAll('.topNavAbs a');

    navLinks.forEach(function(link) {
        link.addEventListener('click', function(e) {
            // Store the clicked category in localStorage
            const category = this.getAttribute('data-category');
            if (category) {
                localStorage.setItem('activeNavCategory', category);
            }

            // Remove active class from all links
            navLinks.forEach(function(l) {
                l.classList.remove('topNavOn');
            });

            // Add active class to clicked link
            this.classList.add('topNavOn');
        });
    });

    // Restore active state from localStorage if no server-side active state
    const storedCategory = localStorage.getItem('activeNavCategory');
    const hasActiveNav = document.querySelector('.topNavAbs .topNavOn');

    if (storedCategory && !hasActiveNav) {
        const targetLink = document.querySelector(`.topNavAbs a[data-category="${storedCategory}"]`);
        if (targetLink) {
            targetLink.classList.add('topNavOn');
        }
    }
});

// Calculator search function
function calcSearch() {
    const searchTerm = document.getElementById('calcSearchTerm').value.toLowerCase().trim();
    const searchOut = document.getElementById('calcSearchOut');
    
    if (searchTerm.length === 0) {
        searchOut.innerHTML = '';
        return false;
    }
    
    // Simple search implementation - in a real implementation, this would be more sophisticated
    const calculators = [
        {name: 'BMI Calculator', url: '<?php echo home_url("/bmi-calculator/"); ?>'},
        {name: 'Mortgage Calculator', url: '<?php echo home_url("/mortgage-calculator/"); ?>'},
        {name: 'Calorie Calculator', url: '<?php echo home_url("/calorie-calculator/"); ?>'},
        {name: 'Body Fat Calculator', url: '<?php echo home_url("/body-fat-calculator/"); ?>'},
        {name: 'Ideal Weight Calculator', url: '<?php echo home_url("/ideal-weight-calculator/"); ?>'},
        {name: 'Loan Calculator', url: '<?php echo home_url("/loan-calculator/"); ?>'},
        {name: 'Investment Calculator', url: '<?php echo home_url("/investment-calculator/"); ?>'},
        {name: 'Retirement Calculator', url: '<?php echo home_url("/retirement-calculator/"); ?>'}
    ];
    
    const results = calculators.filter(calc => 
        calc.name.toLowerCase().includes(searchTerm)
    );
    
    let html = '';
    if (results.length > 0) {
        results.slice(0, 6).forEach(calc => {
            html += `<div><a href="${calc.url}">${calc.name}</a></div>`;
        });
        if (results.length > 6) {
            html += '<div>...</div>';
        }
    } else {
        html = `<div>No calculator matches "${document.getElementById('calcSearchTerm').value}".</div>`;
    }
    
    searchOut.innerHTML = html;
    return false;
}
</script>

</body>
</html>
