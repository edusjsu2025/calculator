<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financial Calculators</title>
    <meta name="description" content="Free financial calculators including mortgage, loan, investment, and retirement calculators.">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<div id="headerout">
    <div id="header">
        <div id="logo">
            <a href="<?php echo home_url(); ?>">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/calculator-white.svg" width="208" height="22" alt="Calculator.net">
            </a>
        </div>
        <div id="login">
            <a href="<?php echo wp_login_url(); ?>">sign in</a>
        </div>
    </div>
</div>

<div id="clear"></div>

<div id="contentout">
    <div id="content">
        <div id="breadcrumbs">
            <a href="<?php echo home_url(); ?>">home</a> / 
            <a href="<?php echo home_url('/financial-calculator/'); ?>">financial calculators</a>
        </div>
        
        <div id="printit">
            <a href="#" onclick="window.print(); return false;">Print</a>
        </div>
        
        <h1>Financial Calculators</h1>
        
        <div class="calculator-categories">
            <div class="calculator-category">
                <h2>Popular Financial Calculators</h2>
                <div class="calculator-list">
                    <a href="<?php echo home_url('/mortgage-calculator/'); ?>">Mortgage Calculator</a>
                    <a href="<?php echo home_url('/loan-calculator/'); ?>">Loan Calculator</a>
                    <a href="<?php echo home_url('/auto-loan-calculator/'); ?>">Auto Loan Calculator</a>
                    <a href="<?php echo home_url('/interest-calculator/'); ?>">Interest Calculator</a>
                    <a href="<?php echo home_url('/payment-calculator/'); ?>">Payment Calculator</a>
                    <a href="<?php echo home_url('/retirement-calculator/'); ?>">Retirement Calculator</a>
                    <a href="<?php echo home_url('/amortization-calculator/'); ?>">Amortization Calculator</a>
                    <a href="<?php echo home_url('/investment-calculator/'); ?>">Investment Calculator</a>
                    <a href="<?php echo home_url('/currency-calculator/'); ?>">Currency Calculator</a>
                    <a href="<?php echo home_url('/inflation-calculator/'); ?>">Inflation Calculator</a>
                </div>
            </div>
        </div>
        
        <p>Our financial calculators help you make informed decisions about loans, mortgages, investments, and retirement planning. All calculators are free to use and provide accurate results based on current financial formulas.</p>
    </div>
    
    <div id="right">
        <div style="padding-top:10px; min-height:280px; text-align:center;">
            <div style="width:336px; height:280px; background:#f0f0f0; border:1px solid #ccc; display:flex; align-items:center; justify-content:center;">
                <span style="color:#999;">Advertisement</span>
            </div>
        </div>
        
        <div id="othercalc">
            <div id="octitle">
                <a href="<?php echo home_url('/financial-calculator/'); ?>">Financial Calculators</a>
            </div>
            <div id="occontent">
                <a href="<?php echo home_url('/mortgage-calculator/'); ?>">Mortgage</a>
                <a href="<?php echo home_url('/loan-calculator/'); ?>">Loan</a>
                <a href="<?php echo home_url('/auto-loan-calculator/'); ?>">Auto Loan</a>
                <a href="<?php echo home_url('/interest-calculator/'); ?>">Interest</a>
                <a href="<?php echo home_url('/payment-calculator/'); ?>">Payment</a>
                <a href="<?php echo home_url('/retirement-calculator/'); ?>">Retirement</a>
                <a href="<?php echo home_url('/amortization-calculator/'); ?>">Amortization</a>
                <a href="<?php echo home_url('/investment-calculator/'); ?>">Investment</a>
                <a href="<?php echo home_url('/currency-calculator/'); ?>">Currency</a>
                <a href="<?php echo home_url('/inflation-calculator/'); ?>">Inflation</a>
                <a href="<?php echo home_url('/financial-calculator/'); ?>">More Financial Calculators</a>
            </div>
            <div id="ocother">
                <a href="<?php echo home_url('/financial-calculator/'); ?>">Financial</a> |
                <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>">Fitness and Health</a> |
                <a href="<?php echo home_url('/math-calculator/'); ?>">Math</a> |
                <a href="<?php echo home_url('/other-calculator/'); ?>">Other</a>
            </div>
        </div>
    </div>
</div>

<div id="clear"></div>

<div id="footer">
    <div id="footerin">
        <div id="footernav">
            <a href="<?php echo home_url('/about-us/'); ?>">about us</a> | 
            <a href="<?php echo home_url('/sitemap/'); ?>">sitemap</a> | 
            <a href="<?php echo home_url('/terms-of-use/'); ?>">terms of use</a> | 
            <a href="<?php echo home_url('/privacy-policy/'); ?>">privacy policy</a> &nbsp; 
            © 2008 - <?php echo date('Y'); ?> <a href="<?php echo home_url(); ?>">calculator.net</a>
        </div>
    </div>
</div>

<!-- Top Navigation (absolute positioned) -->
<div class="topNavAbs">
    <a href="<?php echo home_url('/financial-calculator/'); ?>" class="topNavOn" data-category="financial">Financial</a>
    <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>" data-category="fitness">Fitness &amp; Health</a>
    <a href="<?php echo home_url('/math-calculator/'); ?>" data-category="math">Math</a>
    <a href="<?php echo home_url('/other-calculator/'); ?>" data-category="other">Other</a>
</div>

<?php wp_footer(); ?>

<script>
// Top navigation click handler
document.addEventListener('DOMContentLoaded', function() {
    const navLinks = document.querySelectorAll('.topNavAbs a');
    
    navLinks.forEach(function(link) {
        link.addEventListener('click', function(e) {
            const category = this.getAttribute('data-category');
            if (category) {
                localStorage.setItem('activeNavCategory', category);
            }
            
            navLinks.forEach(function(l) {
                l.classList.remove('topNavOn');
            });
            
            this.classList.add('topNavOn');
        });
    });
    
    // Ensure financial category is active
    const financialLink = document.querySelector('.topNavAbs a[data-category="financial"]');
    if (financialLink && !financialLink.classList.contains('topNavOn')) {
        financialLink.classList.add('topNavOn');
        localStorage.setItem('activeNavCategory', 'financial');
    }
});
</script>

</body>
</html>
