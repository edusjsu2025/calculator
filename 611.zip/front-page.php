<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculator.net - Free Online Calculators</title>
    <meta name="description" content="Free online calculators for finance, fitness, math, and more. Calculate BMI, mortgage payments, loan interest, and hundreds of other calculations.">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<div id="headerout">
    <div id="header">
        <div id="logo">
            <a href="<?php echo home_url(); ?>">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/calculator-white.svg" width="208" height="22" alt="Calculator.net">
            </a>
        </div>
        <div id="login">
            <a href="<?php echo wp_login_url(); ?>">sign in</a>
        </div>
    </div>
</div>

<div id="clear"></div>

<div id="contentout">
    <div id="content">
        <h1>Free Online Calculators</h1>

        <!-- Latest Articles Section -->
        <div style="margin-bottom: 30px;">
            <h2 class="section-title">Latest Articles</h2>

            <?php
            $latest_posts = new WP_Query(array(
                'posts_per_page' => 5,
                'post_status' => 'publish',
                'orderby' => 'date',
                'order' => 'DESC'
            ));

            if ($latest_posts->have_posts()) :
            ?>
            <div class="latest-articles">
                <?php while ($latest_posts->have_posts()) : $latest_posts->the_post(); ?>
                <article class="article-item">
                    <h3>
                        <a href="<?php the_permalink(); ?>">
                            <?php the_title(); ?>
                        </a>
                    </h3>

                    <div class="article-meta">
                        <span>📅 <?php echo get_the_date('F j, Y'); ?></span>
                        <?php if (get_the_category()) : ?>
                            <span> | 📂
                                <?php
                                $categories = get_the_category();
                                echo '<a href="' . get_category_link($categories[0]->term_id) . '">' . $categories[0]->name . '</a>';
                                ?>
                            </span>
                        <?php endif; ?>
                        <?php if (get_comments_number() > 0) : ?>
                            <span> | 💬 <?php echo get_comments_number(); ?> comments</span>
                        <?php endif; ?>
                    </div>

                    <div class="article-excerpt">
                        <?php
                        if (has_excerpt()) {
                            echo get_the_excerpt();
                        } else {
                            echo wp_trim_words(get_the_content(), 35, '...');
                        }
                        ?>
                    </div>

                    <div style="margin-top: 10px;">
                        <a href="<?php the_permalink(); ?>" class="read-more">
                            Read More →
                        </a>
                    </div>
                </article>
                <?php endwhile; ?>
            </div>
            <?php
            wp_reset_postdata();
            else :
            ?>
            <div class="no-articles">
                <p>📝 No articles found. <a href="<?php echo admin_url('post-new.php'); ?>">Create your first post</a> to see it here.</p>
            </div>
            <?php endif; ?>

            <div style="text-align: center; margin-top: 20px;">
                <a href="<?php echo home_url('/blog/'); ?>" class="view-all-articles">
                    📚 View All Articles
                </a>
            </div>
        </div>

        <!-- Calculator Categories -->
        <div id="homelistwrap">
            <!-- Financial Calculators -->
            <div class="calculator-category">
                <h2 class="hh"><a href="<?php echo home_url('/financial-calculator/'); ?>">Financial Calculators</a></h2>
                <ul class="hl">
                    <li><a href="<?php echo home_url('/mortgage-calculator/'); ?>">Mortgage Calculator</a></li>
                    <li><a href="<?php echo home_url('/loan-calculator/'); ?>">Loan Calculator</a></li>
                    <li><a href="<?php echo home_url('/auto-loan-calculator/'); ?>">Auto Loan Calculator</a></li>
                    <li><a href="<?php echo home_url('/interest-calculator/'); ?>">Interest Calculator</a></li>
                    <li><a href="<?php echo home_url('/payment-calculator/'); ?>">Payment Calculator</a></li>
                    <li><a href="<?php echo home_url('/retirement-calculator/'); ?>">Retirement Calculator</a></li>
                    <li><a href="<?php echo home_url('/financial-calculator/'); ?>">More Financial Calculators</a></li>
                </ul>
            </div>

            <!-- Fitness & Health Calculators -->
            <div class="calculator-category">
                <h2 class="hh"><a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>">Fitness &amp; Health Calculators</a></h2>
                <ul class="hl">
                    <li><a href="<?php echo home_url('/bmi-calculator/'); ?>">BMI Calculator</a></li>
                    <li><a href="<?php echo home_url('/calorie-calculator/'); ?>">Calorie Calculator</a></li>
                    <li><a href="<?php echo home_url('/body-fat-calculator/'); ?>">Body Fat Calculator</a></li>
                    <li><a href="<?php echo home_url('/bmr-calculator/'); ?>">BMR Calculator</a></li>
                    <li><a href="<?php echo home_url('/macro-calculator/'); ?>">Macro Calculator</a></li>
                    <li><a href="<?php echo home_url('/ideal-weight-calculator/'); ?>">Ideal Weight Calculator</a></li>
                    <li><a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>">More Fitness and Health Calculators</a></li>
                </ul>
            </div>

            <!-- Math Calculators -->
            <div class="calculator-category">
                <h2 class="hh"><a href="<?php echo home_url('/math-calculator/'); ?>">Math Calculators</a></h2>
                <ul class="hl">
                    <li><a href="<?php echo home_url('/scientific-calculator/'); ?>">Scientific Calculator</a></li>
                    <li><a href="<?php echo home_url('/fraction-calculator/'); ?>">Fraction Calculator</a></li>
                    <li><a href="<?php echo home_url('/percent-calculator/'); ?>">Percentage Calculator</a></li>
                    <li><a href="<?php echo home_url('/triangle-calculator/'); ?>">Triangle Calculator</a></li>
                    <li><a href="<?php echo home_url('/volume-calculator/'); ?>">Volume Calculator</a></li>
                    <li><a href="<?php echo home_url('/math-calculator/'); ?>">More Math Calculators</a></li>
                </ul>
            </div>

            <!-- Other Calculators -->
            <div class="calculator-category">
                <h2 class="hh"><a href="<?php echo home_url('/other-calculator/'); ?>">Other Calculators</a></h2>
                <ul class="hl">
                    <li><a href="<?php echo home_url('/age-calculator/'); ?>">Age Calculator</a></li>
                    <li><a href="<?php echo home_url('/date-calculator/'); ?>">Date Calculator</a></li>
                    <li><a href="<?php echo home_url('/time-calculator/'); ?>">Time Calculator</a></li>
                    <li><a href="<?php echo home_url('/hours-calculator/'); ?>">Hours Calculator</a></li>
                    <li><a href="<?php echo home_url('/gpa-calculator/'); ?>">GPA Calculator</a></li>
                    <li><a href="<?php echo home_url('/grade-calculator/'); ?>">Grade Calculator</a></li>
                    <li><a href="<?php echo home_url('/other-calculator/'); ?>">More Other Calculators</a></li>
                </ul>
            </div>
        </div>
        
        <div style="padding: 20px 0;">
            <h3>About Calculator.net</h3>
            <p>Calculator.net provides free online calculators for finance, fitness, health, math, and other calculations. Our calculators are designed to be accurate, easy to use, and completely free. Whether you need to calculate your BMI, determine mortgage payments, or solve complex mathematical equations, we have the tools you need.</p>
            
            <h3>Popular Calculators</h3>
            <p>Some of our most popular calculators include:</p>
            <ul>
                <li><strong>BMI Calculator</strong> - Calculate your Body Mass Index and determine if you're at a healthy weight</li>
                <li><strong>Mortgage Calculator</strong> - Calculate monthly mortgage payments and total interest costs</li>
                <li><strong>Calorie Calculator</strong> - Determine how many calories you need per day</li>
                <li><strong>Loan Calculator</strong> - Calculate loan payments and interest for any type of loan</li>
                <li><strong>Percentage Calculator</strong> - Calculate percentages, percentage change, and more</li>
            </ul>
            
            <h3>Why Choose Calculator.net?</h3>
            <ul>
                <li><strong>Free to Use</strong> - All our calculators are completely free with no hidden fees</li>
                <li><strong>Accurate Results</strong> - Our calculators use proven formulas and algorithms</li>
                <li><strong>Easy to Use</strong> - Simple, intuitive interfaces that anyone can use</li>
                <li><strong>Mobile Friendly</strong> - All calculators work perfectly on mobile devices</li>
                <li><strong>No Registration Required</strong> - Start calculating immediately without signing up</li>
            </ul>
        </div>
    </div>
    
    <div id="right">
        <div style="padding-top:10px; min-height:280px; text-align:center;">
            <!-- Ad space placeholder -->
            <div style="width:336px; height:280px; background:#f0f0f0; border:1px solid #ccc; display:flex; align-items:center; justify-content:center;">
                <span style="color:#999;">Advertisement</span>
            </div>
        </div>
        
        <form name="calcSearchForm" onsubmit="calcSearch(); return false;" autocomplete="off">
            <table align="center" id="searchbox">
                <tbody>
                    <tr>
                        <td>
                            <input type="text" name="calcSearchTerm" id="calcSearchTerm" class="inlongest" onkeyup="return calcSearch();">
                        </td>
                        <td>
                            <span id="bluebtn" onclick="return calcSearch();">Search</span>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div id="calcSearchOut"></div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </form>

        <div id="othercalc">
            <div id="octitle">
                <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>">Fitness and Health Calculators</a>
            </div>
            <div id="occontent">
                <a href="<?php echo home_url('/bmi-calculator/'); ?>">BMI</a>
                <a href="<?php echo home_url('/calorie-calculator/'); ?>">Calorie</a>
                <a href="<?php echo home_url('/body-fat-calculator/'); ?>">Body Fat</a>
                <a href="<?php echo home_url('/bmr-calculator/'); ?>">BMR</a>
                <a href="<?php echo home_url('/macro-calculator/'); ?>">Macro</a>
                <a href="<?php echo home_url('/ideal-weight-calculator/'); ?>">Ideal Weight</a>
                <a href="<?php echo home_url('/pregnancy-calculator/'); ?>">Pregnancy</a>
                <a href="<?php echo home_url('/pregnancy-weight-gain-calculator/'); ?>">Pregnancy Weight Gain</a>
                <a href="<?php echo home_url('/pregnancy-conception-calculator/'); ?>">Pregnancy Conception</a>
                <a href="<?php echo home_url('/due-date-calculator/'); ?>">Due Date</a>
                <a href="<?php echo home_url('/pace-calculator/'); ?>">Pace</a>
                <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>">More Fitness and Health Calculators</a>
            </div>
            <div id="ocother">
                <a href="<?php echo home_url('/financial-calculator/'); ?>">Financial</a> |
                <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>">Fitness and Health</a> |
                <a href="<?php echo home_url('/math-calculator/'); ?>">Math</a> |
                <a href="<?php echo home_url('/other-calculator/'); ?>">Other</a>
            </div>
        </div>
    </div>
</div>

<div id="clear"></div>

<div id="footer">
    <div id="footerin">
        <div id="footernav">
            <a href="<?php echo home_url('/about-us/'); ?>">about us</a> | 
            <a href="<?php echo home_url('/sitemap/'); ?>">sitemap</a> | 
            <a href="<?php echo home_url('/terms-of-use/'); ?>">terms of use</a> | 
            <a href="<?php echo home_url('/privacy-policy/'); ?>">privacy policy</a> &nbsp; 
            © 2008 - <?php echo date('Y'); ?> <a href="<?php echo home_url(); ?>">calculator.net</a>
        </div>
    </div>
</div>

<!-- Top Navigation (absolute positioned) -->
<div class="topNavAbs">
    <a href="<?php echo home_url('/financial-calculator/'); ?>" data-category="financial">Financial</a>
    <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>" data-category="fitness">Fitness &amp; Health</a>
    <a href="<?php echo home_url('/math-calculator/'); ?>" data-category="math">Math</a>
    <a href="<?php echo home_url('/other-calculator/'); ?>" data-category="other">Other</a>
</div>

<?php wp_footer(); ?>

<script>
// Top navigation click handler to add green background
document.addEventListener('DOMContentLoaded', function() {
    const navLinks = document.querySelectorAll('.topNavAbs a');

    navLinks.forEach(function(link) {
        link.addEventListener('click', function(e) {
            // Store the clicked category in localStorage
            const category = this.getAttribute('data-category');
            if (category) {
                localStorage.setItem('activeNavCategory', category);
            }

            // Remove active class from all links
            navLinks.forEach(function(l) {
                l.classList.remove('topNavOn');
            });

            // Add active class to clicked link
            this.classList.add('topNavOn');
        });
    });

    // Restore active state from localStorage on home page
    const storedCategory = localStorage.getItem('activeNavCategory');
    if (storedCategory) {
        const targetLink = document.querySelector(`.topNavAbs a[data-category="${storedCategory}"]`);
        if (targetLink) {
            targetLink.classList.add('topNavOn');
        }
    }
});

// Calculator search function
function calcSearch() {
    const searchTerm = document.getElementById('calcSearchTerm').value.toLowerCase().trim();
    const searchOut = document.getElementById('calcSearchOut');
    
    if (searchTerm.length === 0) {
        searchOut.innerHTML = '';
        return false;
    }
    
    // Comprehensive calculator list
    const calculators = [
        {name: 'BMI Calculator', url: '<?php echo home_url("/bmi-calculator/"); ?>'},
        {name: 'Mortgage Calculator', url: '<?php echo home_url("/mortgage-calculator/"); ?>'},
        {name: 'Calorie Calculator', url: '<?php echo home_url("/calorie-calculator/"); ?>'},
        {name: 'Body Fat Calculator', url: '<?php echo home_url("/body-fat-calculator/"); ?>'},
        {name: 'Ideal Weight Calculator', url: '<?php echo home_url("/ideal-weight-calculator/"); ?>'},
        {name: 'Loan Calculator', url: '<?php echo home_url("/loan-calculator/"); ?>'},
        {name: 'Investment Calculator', url: '<?php echo home_url("/investment-calculator/"); ?>'},
        {name: 'Retirement Calculator', url: '<?php echo home_url("/retirement-calculator/"); ?>'},
        {name: 'Percentage Calculator', url: '<?php echo home_url("/percentage-calculator/"); ?>'},
        {name: 'Age Calculator', url: '<?php echo home_url("/age-calculator/"); ?>'},
        {name: 'Scientific Calculator', url: '<?php echo home_url("/scientific-calculator/"); ?>'},
        {name: 'Fraction Calculator', url: '<?php echo home_url("/fraction-calculator/"); ?>'},
        {name: 'Auto Loan Calculator', url: '<?php echo home_url("/auto-loan-calculator/"); ?>'},
        {name: 'Interest Calculator', url: '<?php echo home_url("/interest-calculator/"); ?>'},
        {name: 'Payment Calculator', url: '<?php echo home_url("/payment-calculator/"); ?>'},
        {name: 'Amortization Calculator', url: '<?php echo home_url("/amortization-calculator/"); ?>'},
        {name: 'Currency Calculator', url: '<?php echo home_url("/currency-calculator/"); ?>'},
        {name: 'Inflation Calculator', url: '<?php echo home_url("/inflation-calculator/"); ?>'},
        {name: 'BMR Calculator', url: '<?php echo home_url("/bmr-calculator/"); ?>'},
        {name: 'Macro Calculator', url: '<?php echo home_url("/macro-calculator/"); ?>'},
        {name: 'Pregnancy Calculator', url: '<?php echo home_url("/pregnancy-calculator/"); ?>'},
        {name: 'Due Date Calculator', url: '<?php echo home_url("/due-date-calculator/"); ?>'},
        {name: 'Triangle Calculator', url: '<?php echo home_url("/triangle-calculator/"); ?>'},
        {name: 'Volume Calculator', url: '<?php echo home_url("/volume-calculator/"); ?>'},
        {name: 'Standard Deviation Calculator', url: '<?php echo home_url("/standard-deviation-calculator/"); ?>'},
        {name: 'Random Number Generator', url: '<?php echo home_url("/random-number-generator/"); ?>'},
        {name: 'Date Calculator', url: '<?php echo home_url("/date-calculator/"); ?>'},
        {name: 'Time Calculator', url: '<?php echo home_url("/time-calculator/"); ?>'},
        {name: 'Hours Calculator', url: '<?php echo home_url("/hours-calculator/"); ?>'},
        {name: 'GPA Calculator', url: '<?php echo home_url("/gpa-calculator/"); ?>'},
        {name: 'Grade Calculator', url: '<?php echo home_url("/grade-calculator/"); ?>'}
    ];
    
    const results = calculators.filter(calc => 
        calc.name.toLowerCase().includes(searchTerm)
    );
    
    let html = '';
    if (results.length > 0) {
        results.slice(0, 6).forEach(calc => {
            html += `<div><a href="${calc.url}">${calc.name}</a></div>`;
        });
        if (results.length > 6) {
            html += '<div>...</div>';
        }
    } else {
        html = `<div>No calculator matches "${document.getElementById('calcSearchTerm').value}".</div>`;
    }
    
    searchOut.innerHTML = html;
    return false;
}
</script>

</body>
</html>
