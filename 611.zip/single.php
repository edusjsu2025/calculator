<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php wp_title('|', true, 'right'); ?><?php bloginfo('name'); ?></title>
    <meta name="description" content="<?php echo wp_trim_words(get_the_excerpt(), 25, '...'); ?>">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<div id="headerout">
    <div id="header">
        <div id="logo">
            <a href="<?php echo home_url(); ?>">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/calculator-white.svg" width="208" height="22" alt="Calculator.net">
            </a>
        </div>
        <div id="login">
            <a href="<?php echo wp_login_url(); ?>">sign in</a>
        </div>
    </div>
</div>

<div id="clear"></div>

<div id="contentout">
    <div id="content">
        <?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>

            <div id="breadcrumbs" itemscope itemtype="https://schema.org/BreadcrumbList">
                <span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
                    <a href="<?php echo home_url(); ?>" itemprop="item"><span itemprop="name">home</span></a>
                    <meta itemprop="position" content="1">
                </span> /
                <span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
                    <a href="<?php echo home_url('/blog/'); ?>" itemprop="item"><span itemprop="name">blog</span></a>
                    <meta itemprop="position" content="2">
                </span> /
                <?php if (get_the_category()) : ?>
                    <?php
                    $categories = get_the_category();
                    echo '<span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
                    echo '<a href="' . get_category_link($categories[0]->term_id) . '" itemprop="item"><span itemprop="name">' . strtolower($categories[0]->name) . '</span></a>';
                    echo '<meta itemprop="position" content="3">';
                    echo '</span> / ';
                    ?>
                <?php endif; ?>
                <span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
                    <a href="<?php the_permalink(); ?>" itemprop="item"><span itemprop="name"><?php echo strtolower(wp_trim_words(get_the_title(), 5, '...')); ?></span></a>
                    <meta itemprop="position" content="4">
                </span>
            </div>

            <div id="printit">
                <a href="#" onclick="window.print(); return false;">Print</a>
            </div>

            <h1><?php the_title(); ?></h1>

            <br>
            <div class="article-content">
                <?php the_content(); ?>
            </div>

            <?php endwhile; ?>
        <?php endif; ?>
    </div>
    
    <div id="right">
        <div style="padding-top:10px; min-height:280px; text-align:center;">
            <div style="width:336px; height:280px; background:#f0f0f0; border:1px solid #ccc; display:flex; align-items:center; justify-content:center;">
                <span style="color:#999;">Advertisement</span>
            </div>
        </div>

        <form name="calcSearchForm" onsubmit="calcSearch(); return false;" autocomplete="off">
            <table align="center" id="searchbox">
                <tbody>
                    <tr>
                        <td>
                            <input type="text" name="calcSearchTerm" id="calcSearchTerm" class="inlongest" onkeyup="return calcSearch();">
                        </td>
                        <td>
                            <span id="bluebtn" onclick="return calcSearch();">Search</span>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div id="calcSearchOut"></div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </form>

        <div id="othercalc">
            <div id="octitle">
                <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>">Fitness and Health Calculators</a>
            </div>
            <div id="occontent">
                <a href="<?php echo home_url('/bmi-calculator/'); ?>">BMI</a>
                <a href="<?php echo home_url('/calorie-calculator/'); ?>">Calorie</a>
                <a href="<?php echo home_url('/body-fat-calculator/'); ?>">Body Fat</a>
                <a href="<?php echo home_url('/bmr-calculator/'); ?>">BMR</a>
                <a href="<?php echo home_url('/macro-calculator/'); ?>">Macro</a>
                <a href="<?php echo home_url('/ideal-weight-calculator/'); ?>">Ideal Weight</a>
                <a href="<?php echo home_url('/pregnancy-calculator/'); ?>">Pregnancy</a>
                <a href="<?php echo home_url('/pregnancy-weight-gain-calculator/'); ?>">Pregnancy Weight Gain</a>
                <a href="<?php echo home_url('/pregnancy-conception-calculator/'); ?>">Pregnancy Conception</a>
                <a href="<?php echo home_url('/due-date-calculator/'); ?>">Due Date</a>
                <a href="<?php echo home_url('/pace-calculator/'); ?>">Pace</a>
                <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>">More Fitness and Health Calculators</a>
            </div>
            <div id="ocother">
                <a href="<?php echo home_url('/financial-calculator/'); ?>">Financial</a> |
                <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>">Fitness and Health</a> |
                <a href="<?php echo home_url('/math-calculator/'); ?>">Math</a> |
                <a href="<?php echo home_url('/other-calculator/'); ?>">Other</a>
            </div>
        </div>
    </div>
</div>

<div id="clear"></div>

<div id="footer">
    <div id="footerin">
        <div id="footernav">
            <a href="<?php echo home_url('/about-us/'); ?>">about us</a> | 
            <a href="<?php echo home_url('/sitemap/'); ?>">sitemap</a> | 
            <a href="<?php echo home_url('/terms-of-use/'); ?>">terms of use</a> | 
            <a href="<?php echo home_url('/privacy-policy/'); ?>">privacy policy</a> &nbsp; 
            © 2008 - <?php echo date('Y'); ?> <a href="<?php echo home_url(); ?>">calculator.net</a>
        </div>
    </div>
</div>

<!-- Top Navigation (absolute positioned) -->
<div class="topNavAbs">
    <a href="<?php echo home_url('/financial-calculator/'); ?>" data-category="financial">Financial</a>
    <a href="<?php echo home_url('/fitness-and-health-calculator/'); ?>" data-category="fitness">Fitness &amp; Health</a>
    <a href="<?php echo home_url('/math-calculator/'); ?>" data-category="math">Math</a>
    <a href="<?php echo home_url('/other-calculator/'); ?>" data-category="other">Other</a>
</div>

<?php wp_footer(); ?>

<script>
// Top navigation click handler
document.addEventListener('DOMContentLoaded', function() {
    const navLinks = document.querySelectorAll('.topNavAbs a');
    
    navLinks.forEach(function(link) {
        link.addEventListener('click', function(e) {
            const category = this.getAttribute('data-category');
            if (category) {
                localStorage.setItem('activeNavCategory', category);
            }
            
            navLinks.forEach(function(l) {
                l.classList.remove('topNavOn');
            });
            
            this.classList.add('topNavOn');
        });
    });
    
    // Restore active state from localStorage
    const storedCategory = localStorage.getItem('activeNavCategory');
    if (storedCategory) {
        const targetLink = document.querySelector(`.topNavAbs a[data-category="${storedCategory}"]`);
        if (targetLink) {
            targetLink.classList.add('topNavOn');
        }
    }
});

// Calculator search function
function calcSearch() {
    const searchTerm = document.getElementById('calcSearchTerm').value.toLowerCase().trim();
    const searchOut = document.getElementById('calcSearchOut');

    if (searchTerm.length === 0) {
        searchOut.innerHTML = '';
        return false;
    }

    const calculators = [
        {name: 'BMI Calculator', url: '<?php echo home_url("/bmi-calculator/"); ?>'},
        {name: 'Mortgage Calculator', url: '<?php echo home_url("/mortgage-calculator/"); ?>'},
        {name: 'Calorie Calculator', url: '<?php echo home_url("/calorie-calculator/"); ?>'},
        {name: 'Body Fat Calculator', url: '<?php echo home_url("/body-fat-calculator/"); ?>'},
        {name: 'Ideal Weight Calculator', url: '<?php echo home_url("/ideal-weight-calculator/"); ?>'},
        {name: 'Loan Calculator', url: '<?php echo home_url("/loan-calculator/"); ?>'},
        {name: 'Investment Calculator', url: '<?php echo home_url("/investment-calculator/"); ?>'},
        {name: 'Retirement Calculator', url: '<?php echo home_url("/retirement-calculator/"); ?>'}
    ];

    const results = calculators.filter(calc =>
        calc.name.toLowerCase().includes(searchTerm)
    );

    let html = '';
    if (results.length > 0) {
        results.slice(0, 6).forEach(calc => {
            html += `<div><a href="${calc.url}">${calc.name}</a></div>`;
        });
        if (results.length > 6) {
            html += '<div>...</div>';
        }
    } else {
        html = `<div>No calculator matches "${document.getElementById('calcSearchTerm').value}".</div>`;
    }

    searchOut.innerHTML = html;
    return false;
}
</script>

</body>
</html>
