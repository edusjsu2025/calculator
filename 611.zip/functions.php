<?php
/**
 * Calculator Net Clone Theme Functions
 */

// Theme setup
function calculator_theme_setup() {
    // Add theme support for various features
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'calculator-theme'),
        'footer' => __('Footer Menu', 'calculator-theme'),
    ));
}
add_action('after_setup_theme', 'calculator_theme_setup');

// Enqueue scripts and styles
function calculator_theme_scripts() {
    wp_enqueue_style('calculator-style', get_stylesheet_uri());

    // 加载WordPress兼容性CSS，优先级更高
    wp_enqueue_style('calculator-wp-compatibility', get_template_directory_uri() . '/wordpress-compatibility.css', array('calculator-style'), '1.0.0');

    wp_enqueue_script('calculator-common', get_template_directory_uri() . '/assets/js/common.js', array(), '1.0.0', true);
    wp_enqueue_script('calculator-main', get_template_directory_uri() . '/assets/js/calculator.js', array('jquery'), '1.0.0', true);

    // 加载布局修复JavaScript，优先级最高
    wp_enqueue_script('calculator-layout-fix', get_template_directory_uri() . '/assets/js/layout-fix.js', array(), '1.0.0', true);

    // Localize script for AJAX
    wp_localize_script('calculator-main', 'calculator_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('calculator_nonce')
    ));
}
add_action('wp_enqueue_scripts', 'calculator_theme_scripts');

// Register widget areas
function calculator_theme_widgets_init() {
    register_sidebar(array(
        'name'          => __('Right Sidebar', 'calculator-theme'),
        'id'            => 'sidebar-1',
        'description'   => __('Add widgets here.', 'calculator-theme'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));
}
add_action('widgets_init', 'calculator_theme_widgets_init');

// Custom post type for calculators
function create_calculator_post_type() {
    register_post_type('calculator',
        array(
            'labels' => array(
                'name' => __('Calculators'),
                'singular_name' => __('Calculator')
            ),
            'public' => true,
            'has_archive' => true,
            'supports' => array('title', 'editor', 'custom-fields'),
            'menu_icon' => 'dashicons-calculator',
            'rewrite' => array('slug' => 'calculator'),
        )
    );
}
add_action('init', 'create_calculator_post_type');

// Add calculator categories taxonomy
function create_calculator_taxonomy() {
    register_taxonomy(
        'calculator_category',
        'calculator',
        array(
            'label' => __('Calculator Categories'),
            'rewrite' => array('slug' => 'calculator-category'),
            'hierarchical' => true,
        )
    );
}
add_action('init', 'create_calculator_taxonomy');

// AJAX handler for BMI calculation
function handle_bmi_calculation() {
    check_ajax_referer('calculator_nonce', 'nonce');
    
    $age = floatval($_POST['age']);
    $gender = sanitize_text_field($_POST['gender']);
    $height = floatval($_POST['height']);
    $weight = floatval($_POST['weight']);
    $unit_type = sanitize_text_field($_POST['unit_type']);
    
    // Convert to metric if needed
    if ($unit_type === 'standard') {
        $height_feet = floor($height);
        $height_inches = ($height - $height_feet) * 12;
        $height = ($height_feet * 12 + $height_inches) * 2.54; // Convert to cm
        $weight = $weight * 0.453592; // Convert pounds to kg
    }
    
    // Calculate BMI
    $height_m = $height / 100; // Convert cm to meters
    $bmi = $weight / ($height_m * $height_m);
    
    // Determine BMI category
    $category = '';
    $color = '';
    if ($bmi < 16) {
        $category = 'Severe Thinness';
        $color = '#bc2020';
    } elseif ($bmi < 17) {
        $category = 'Moderate Thinness';
        $color = '#d38888';
    } elseif ($bmi < 18.5) {
        $category = 'Mild Thinness';
        $color = '#ffe400';
    } elseif ($bmi < 25) {
        $category = 'Normal';
        $color = '#008137';
    } elseif ($bmi < 30) {
        $category = 'Overweight';
        $color = '#ffe400';
    } elseif ($bmi < 35) {
        $category = 'Obese Class I';
        $color = '#d38888';
    } elseif ($bmi < 40) {
        $category = 'Obese Class II';
        $color = '#bc2020';
    } else {
        $category = 'Obese Class III';
        $color = '#8a0101';
    }
    
    // Calculate healthy weight range
    $healthy_min = 18.5 * ($height_m * $height_m);
    $healthy_max = 25 * ($height_m * $height_m);
    
    // Calculate BMI Prime
    $bmi_prime = $bmi / 25;
    
    // Calculate Ponderal Index
    $ponderal_index = $weight / ($height_m * $height_m * $height_m);
    
    $response = array(
        'bmi' => round($bmi, 1),
        'category' => $category,
        'color' => $color,
        'healthy_min' => round($healthy_min, 1),
        'healthy_max' => round($healthy_max, 1),
        'bmi_prime' => round($bmi_prime, 1),
        'ponderal_index' => round($ponderal_index, 1)
    );
    
    wp_send_json_success($response);
}
add_action('wp_ajax_calculate_bmi', 'handle_bmi_calculation');
add_action('wp_ajax_nopriv_calculate_bmi', 'handle_bmi_calculation');

// Custom breadcrumb function
function calculator_breadcrumb() {
    if (!is_home()) {
        echo '<div id="breadcrumbs" itemscope itemtype="https://schema.org/BreadcrumbList">';
        echo '<span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
        echo '<a href="' . home_url() . '" itemprop="item"><span itemprop="name">home</span></a>';
        echo '<meta itemprop="position" content="1"></span> / ';
        
        if (is_category() || is_single()) {
            $category = get_the_category();
            if ($category) {
                echo '<span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
                echo '<a href="' . get_category_link($category[0]->term_id) . '" itemprop="item">';
                echo '<span itemprop="name">' . $category[0]->name . '</span></a>';
                echo '<meta itemprop="position" content="2"></span> / ';
            }
        }
        
        if (is_single()) {
            echo '<span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
            echo '<a href="' . get_permalink() . '" itemprop="item">';
            echo '<span itemprop="name">' . get_the_title() . '</span></a>';
            echo '<meta itemprop="position" content="3"></span>';
        }
        
        echo '</div>';
    }
}

// Get calculator categories for navigation
function get_calculator_categories() {
    return array(
        'financial' => array(
            'name' => 'Financial',
            'url' => home_url('/financial-calculator/'),
            'calculators' => array(
                'mortgage-calculator' => 'Mortgage Calculator',
                'loan-calculator' => 'Loan Calculator',
                'investment-calculator' => 'Investment Calculator',
                'retirement-calculator' => 'Retirement Calculator',
                'auto-loan-calculator' => 'Auto Loan Calculator',
                'interest-calculator' => 'Interest Calculator',
                'payment-calculator' => 'Payment Calculator',
                'amortization-calculator' => 'Amortization Calculator'
            )
        ),
        'fitness' => array(
            'name' => 'Fitness & Health',
            'url' => home_url('/fitness-and-health-calculator/'),
            'calculators' => array(
                'bmi-calculator' => 'BMI Calculator',
                'calorie-calculator' => 'Calorie Calculator',
                'body-fat-calculator' => 'Body Fat Calculator',
                'ideal-weight-calculator' => 'Ideal Weight Calculator',
                'bmr-calculator' => 'BMR Calculator',
                'macro-calculator' => 'Macro Calculator',
                'pregnancy-calculator' => 'Pregnancy Calculator'
            )
        ),
        'math' => array(
            'name' => 'Math',
            'url' => home_url('/math-calculator/'),
            'calculators' => array(
                'percentage-calculator' => 'Percentage Calculator',
                'fraction-calculator' => 'Fraction Calculator',
                'scientific-calculator' => 'Scientific Calculator',
                'triangle-calculator' => 'Triangle Calculator',
                'volume-calculator' => 'Volume Calculator'
            )
        ),
        'other' => array(
            'name' => 'Other',
            'url' => home_url('/other-calculator/'),
            'calculators' => array(
                'age-calculator' => 'Age Calculator',
                'date-calculator' => 'Date Calculator',
                'time-calculator' => 'Time Calculator',
                'hours-calculator' => 'Hours Calculator',
                'gpa-calculator' => 'GPA Calculator'
            )
        )
    );
}

// Get current page category
function get_current_page_category() {
    global $post;

    if (!$post) return '';

    // Get current page slug
    $page_slug = $post->post_name;

    // Check if it's a calculator page
    $categories = get_calculator_categories();

    foreach ($categories as $cat_key => $category) {
        foreach ($category['calculators'] as $calc_slug => $calc_name) {
            if ($page_slug === $calc_slug || $page_slug === str_replace('-calculator', '', $calc_slug)) {
                return $cat_key;
            }
        }

        // Check if it's a category page
        if (strpos($page_slug, $cat_key) !== false ||
            strpos($page_slug, str_replace(' ', '-', strtolower($category['name']))) !== false) {
            return $cat_key;
        }
    }

    // Special cases
    if (strpos($page_slug, 'bmi') !== false) return 'fitness';
    if (strpos($page_slug, 'mortgage') !== false) return 'financial';
    if (strpos($page_slug, 'calorie') !== false) return 'fitness';
    if (strpos($page_slug, 'loan') !== false) return 'financial';

    return '';
}

// Add custom meta boxes for calculator settings
function add_calculator_meta_boxes() {
    add_meta_box(
        'calculator-settings',
        'Calculator Settings',
        'calculator_settings_callback',
        'calculator'
    );
}
add_action('add_meta_boxes', 'add_calculator_meta_boxes');

function calculator_settings_callback($post) {
    wp_nonce_field('calculator_settings_nonce', 'calculator_settings_nonce');
    
    $calculator_type = get_post_meta($post->ID, '_calculator_type', true);
    $calculator_category = get_post_meta($post->ID, '_calculator_category', true);
    
    echo '<table class="form-table">';
    echo '<tr>';
    echo '<th><label for="calculator_type">Calculator Type</label></th>';
    echo '<td>';
    echo '<select id="calculator_type" name="calculator_type">';
    echo '<option value="bmi"' . selected($calculator_type, 'bmi', false) . '>BMI Calculator</option>';
    echo '<option value="mortgage"' . selected($calculator_type, 'mortgage', false) . '>Mortgage Calculator</option>';
    echo '<option value="calorie"' . selected($calculator_type, 'calorie', false) . '>Calorie Calculator</option>';
    echo '</select>';
    echo '</td>';
    echo '</tr>';
    echo '<tr>';
    echo '<th><label for="calculator_category">Category</label></th>';
    echo '<td>';
    echo '<select id="calculator_category" name="calculator_category">';
    echo '<option value="financial"' . selected($calculator_category, 'financial', false) . '>Financial</option>';
    echo '<option value="fitness"' . selected($calculator_category, 'fitness', false) . '>Fitness & Health</option>';
    echo '<option value="math"' . selected($calculator_category, 'math', false) . '>Math</option>';
    echo '<option value="other"' . selected($calculator_category, 'other', false) . '>Other</option>';
    echo '</select>';
    echo '</td>';
    echo '</tr>';
    echo '</table>';
}

function save_calculator_settings($post_id) {
    if (!isset($_POST['calculator_settings_nonce']) || !wp_verify_nonce($_POST['calculator_settings_nonce'], 'calculator_settings_nonce')) {
        return;
    }
    
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    if (isset($_POST['calculator_type'])) {
        update_post_meta($post_id, '_calculator_type', sanitize_text_field($_POST['calculator_type']));
    }
    
    if (isset($_POST['calculator_category'])) {
        update_post_meta($post_id, '_calculator_category', sanitize_text_field($_POST['calculator_category']));
    }
}
add_action('save_post', 'save_calculator_settings');

// Fix image paths in content for WordPress
function fix_content_image_paths($content) {
    // Get theme directory URI
    $theme_uri = get_template_directory_uri();

    // Replace various relative image path patterns
    $patterns = array(
        'src="assets/images/' => 'src="' . $theme_uri . '/assets/images/',
        "src='assets/images/" => "src='" . $theme_uri . '/assets/images/',
        'src="./assets/images/' => 'src="' . $theme_uri . '/assets/images/',
        "src='./assets/images/" => "src='" . $theme_uri . '/assets/images/',
        'src="images/' => 'src="' . $theme_uri . '/assets/images/',
        "src='images/" => "src='" . $theme_uri . '/assets/images/',
        'src="../images/' => 'src="' . $theme_uri . '/assets/images/',
        "src='../images/" => "src='" . $theme_uri . '/assets/images/',
    );

    // Apply all replacements
    foreach ($patterns as $search => $replace) {
        $content = str_replace($search, $replace, $content);
    }

    // Handle WordPress uploads directory
    $upload_dir = wp_upload_dir();
    $content = str_replace('src="uploads/', 'src="' . $upload_dir['baseurl'] . '/', $content);
    $content = str_replace("src='uploads/", "src='" . $upload_dir['baseurl'] . '/', $content);

    return $content;
}
add_filter('the_content', 'fix_content_image_paths');
add_filter('the_excerpt', 'fix_content_image_paths');

// Also fix paths in widget content
add_filter('widget_text', 'fix_content_image_paths');

// Enhanced shortcode for theme images
function theme_image_shortcode($atts) {
    $atts = shortcode_atts(array(
        'src' => '',
        'alt' => '',
        'width' => '',
        'height' => '',
        'class' => '',
        'style' => ''
    ), $atts);

    if (empty($atts['src'])) {
        return '<!-- Error: No image source specified -->';
    }

    // Use the enhanced theme image function
    $img = get_theme_image($atts['src'], $atts['alt'], $atts['width'], $atts['height'], $atts['class']);

    // Add custom style if specified
    if (!empty($atts['style'])) {
        $img = str_replace('<img ', '<img style="' . esc_attr($atts['style']) . '" ', $img);
    }

    return $img;
}
add_shortcode('theme_image', 'theme_image_shortcode');

// Helper function to get theme image URL
function get_theme_image_url($image_name) {
    $theme_uri = get_template_directory_uri();
    $image_path = '/assets/images/' . ltrim($image_name, '/');
    return $theme_uri . $image_path;
}

// Function to check if theme image exists
function theme_image_exists($image_name) {
    $image_path = get_template_directory() . '/assets/images/' . ltrim($image_name, '/');
    return file_exists($image_path);
}

// Enhanced theme image function with fallback
function get_theme_image($image_name, $alt = '', $width = '', $height = '', $class = '') {
    if (!theme_image_exists($image_name)) {
        return '<!-- Image not found: ' . esc_html($image_name) . ' -->';
    }

    $src = get_theme_image_url($image_name);
    $alt = esc_attr($alt);
    $width = $width ? 'width="' . esc_attr($width) . '"' : '';
    $height = $height ? 'height="' . esc_attr($height) . '"' : '';
    $class = $class ? 'class="' . esc_attr($class) . '"' : '';

    return '<img src="' . esc_url($src) . '" alt="' . $alt . '" ' . $width . ' ' . $height . ' ' . $class . '>';
}

// Add to WordPress editor for easy use
function add_theme_image_button() {
    if (current_user_can('edit_posts') && current_user_can('edit_pages')) {
        add_filter('mce_external_plugins', 'add_theme_image_plugin');
        add_filter('mce_buttons', 'register_theme_image_button');
    }
}
add_action('admin_head', 'add_theme_image_button');

function add_theme_image_plugin($plugin_array) {
    $plugin_array['theme_image'] = get_template_directory_uri() . '/assets/js/theme-image-plugin.js';
    return $plugin_array;
}

function register_theme_image_button($buttons) {
    array_push($buttons, 'theme_image');
    return $buttons;
}

// 添加超强力内联CSS来强制修复WordPress HTML模块中的布局问题
function add_layout_fix_css() {
    ?>
    <style type="text/css">
    /* 超强力WordPress HTML模块布局修复 - 覆盖所有可能的容器 */
    #contentout,
    .wp-block-html #contentout,
    .wp-block-shortcode #contentout,
    .elementor-widget-html #contentout,
    .widget_text #contentout,
    .textwidget #contentout,
    .entry-content #contentout,
    .post-content #contentout,
    .article-content #contentout,
    div[class*="content"] #contentout,
    div[id*="content"] #contentout,
    div[class*="post"] #contentout,
    div[id*="post"] #contentout,
    div[class*="article"] #contentout,
    div[id*="article"] #contentout {
        width: 1100px !important;
        margin: 0 auto !important;
        overflow: auto !important;
        display: block !important;
        position: relative !important;
        clear: both !important;
        padding-top: 5px !important;
        text-align: left !important;
        max-width: none !important;
        min-width: 1100px !important;
        box-sizing: content-box !important;
    }

    #content,
    .wp-block-html #content,
    .wp-block-shortcode #content,
    .elementor-widget-html #content,
    .widget_text #content,
    .textwidget #content,
    .entry-content #content,
    .post-content #content,
    .article-content #content,
    div[class*="content"] #content,
    div[id*="content"] #content,
    div[class*="post"] #content,
    div[id*="post"] #content,
    div[class*="article"] #content,
    div[id*="article"] #content {
        width: 728px !important;
        float: left !important;
        padding: 0px 0px 15px 0px !important;
        box-sizing: border-box !important;
        margin: 0 !important;
        display: block !important;
        position: relative !important;
        clear: none !important;
        max-width: 728px !important;
        min-width: 728px !important;
    }

    #right,
    .wp-block-html #right,
    .wp-block-shortcode #right,
    .elementor-widget-html #right,
    .widget_text #right,
    .textwidget #right,
    .entry-content #right,
    .post-content #right,
    .article-content #right,
    div[class*="content"] #right,
    div[id*="content"] #right,
    div[class*="post"] #right,
    div[id*="post"] #right,
    div[class*="article"] #right,
    div[id*="article"] #right {
        width: 336px !important;
        float: right !important;
        text-align: center !important;
        padding: 0px !important;
        box-sizing: border-box !important;
        margin: 0 !important;
        display: block !important;
        position: relative !important;
        clear: none !important;
        max-width: 336px !important;
        min-width: 336px !important;
        height: auto !important;
        overflow: visible !important;
    }

    /* 确保清除浮动 */
    #contentout::after,
    .wp-block-html #contentout::after,
    .wp-block-shortcode #contentout::after,
    .elementor-widget-html #contentout::after,
    .widget_text #contentout::after,
    .textwidget #contentout::after,
    .entry-content #contentout::after,
    .post-content #contentout::after,
    .article-content #contentout::after,
    div[class*="content"] #contentout::after,
    div[id*="content"] #contentout::after,
    div[class*="post"] #contentout::after,
    div[id*="post"] #contentout::after,
    div[class*="article"] #contentout::after,
    div[id*="article"] #contentout::after {
        content: "" !important;
        display: table !important;
        clear: both !important;
    }

    /* 强制重置可能干扰的WordPress样式 */
    #contentout * {
        box-sizing: border-box !important;
    }

    /* 移动端适配 */
    @media (max-width: 720px) {
        #contentout,
        .wp-block-html #contentout,
        .wp-block-shortcode #contentout,
        .elementor-widget-html #contentout,
        .widget_text #contentout,
        .textwidget #contentout,
        .entry-content #contentout,
        .post-content #contentout,
        .article-content #contentout,
        div[class*="content"] #contentout,
        div[id*="content"] #contentout,
        div[class*="post"] #contentout,
        div[id*="post"] #contentout,
        div[class*="article"] #contentout,
        div[id*="article"] #contentout {
            width: auto !important;
            padding: 8px !important;
            min-width: auto !important;
        }

        #content,
        .wp-block-html #content,
        .wp-block-shortcode #content,
        .elementor-widget-html #content,
        .widget_text #content,
        .textwidget #content,
        .entry-content #content,
        .post-content #content,
        .article-content #content,
        div[class*="content"] #content,
        div[id*="content"] #content,
        div[class*="post"] #content,
        div[id*="post"] #content,
        div[class*="article"] #content,
        div[id*="article"] #content {
            width: auto !important;
            float: none !important;
            padding: 0px !important;
            min-width: auto !important;
            max-width: none !important;
        }

        #right,
        .wp-block-html #right,
        .wp-block-shortcode #right,
        .elementor-widget-html #right,
        .widget_text #right,
        .textwidget #right,
        .entry-content #right,
        .post-content #right,
        .article-content #right,
        div[class*="content"] #right,
        div[id*="content"] #right,
        div[class*="post"] #right,
        div[id*="post"] #right,
        div[class*="article"] #right,
        div[id*="article"] #right {
            width: auto !important;
            float: none !important;
            margin-top: 20px !important;
            min-width: auto !important;
            max-width: none !important;
        }
    }
    </style>
    <?php
}
add_action('wp_head', 'add_layout_fix_css');

// 添加body class来帮助识别页面类型
function add_calculator_body_class($classes) {
    if (is_single() || is_page()) {
        $classes[] = 'calculator-layout';
    }
    return $classes;
}
add_filter('body_class', 'add_calculator_body_class');
?>
